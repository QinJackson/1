#rm /data/新版本优化.sh

read input

if [ "$input" == "1" ]; then
    
    
    /data/user/0/com.aide.ui/no_backup/ndksupport-1710240003/android-ndk-aide/ndk-build -j14
else
    echo "已跳过执行命令"
fi

cp ./libs/arm64-v8a/新版本优化.sh /data/测试111/新版本优化.sh
chmod 777 /data/测试111/新版本优化.sh
echo "2" | /data/测试111/新版本优化.sh
