string PlayerCharacter(int id)
{            
             string PlayerName;
	         if (id==155)
			 {
               PlayerName = "艾琳";
             }
             else if (id==105)
			 {
                PlayerName = "廉颇";
			 }
              else if (id == 106)
			  {
				  PlayerName = "小乔";
              }
			  else if(id == 107)
			  {
				  PlayerName = "赵云";
			  }
			  else if (id == 108)
			  {
				  PlayerName = "墨子";
              }
			  else if (id == 109)
			  {
				  PlayerName = "妲己";
              }
			  else if(id == 110)
			  {
				 PlayerName = "嬴政";
			  }
			  else if(id == 111)
			  {
				  PlayerName = "孙尚香";
			  }
			  else if (id == 112)
			  {
				  PlayerName = "鲁班七号";
              }
			  else if (id == 113)
			  {
				  PlayerName = "庄周";
              }
			  else if (id == 114)
			  {
				  PlayerName = "刘禅";
              }
			  else if (id == 115)
			  {
				  PlayerName = "高渐离";
              }
			  else if (id == 116)
			  {
				  PlayerName = "阿珂";
              }
			  else if (id == 117)
			  {
				  PlayerName = "钟无艳";
              }
			  else if (id == 118)
			  {
				  PlayerName = "孙膑";
              }
			  else if (id == 119)
			  {
				  PlayerName = "扁鹊";
              }
			  else if (id == 120)
			  {
				  PlayerName = "白起";
              }
			  else if (id == 121)
			  {
				  PlayerName = "芈月";
              }
			  else if (id == 123)
			  {
				  PlayerName = "吕布";
              }
			  else if (id == 124)
			  {
				  PlayerName = "周瑜";
              }
			  else if (id == 125)
			  {
				  PlayerName = "元歌";
              }
			  else if (id == 126)
			  {
				  PlayerName = "夏侯惇";
              }
			  else if (id == 127)
			  {
				  PlayerName = "甄姬";
              }
			  else if (id == 128)
			  {
				  PlayerName = "曹操";
              }
			  else if (id == 129)
			  {
				  PlayerName = "典韦";
              }
			  else if (id == 130)
			  {
				  PlayerName = "宫本武藏";
              }
			  else if (id == 131)
			  {
				  PlayerName = "李白";
              }
			  else if (id == 132)
			  {
				  PlayerName = "马克";
              }
			  else if (id == 133)
			  {
				  PlayerName = "狄仁杰";
              }
			  else if (id == 134)
			  {
				  PlayerName = "达摩";
              }
			  else if (id == 135)
			  {
				  PlayerName = "项羽";
              }
			  else if (id == 136)
			  {
				  PlayerName = "武则天";
              }
			  else if (id == 137)
			  {
				  PlayerName = "司马懿";
              }
			  else if (id == 139)
			  {
				  PlayerName = "老夫子";
              }
			  else if (id == 140)
			  {
				  PlayerName = "关羽";
              }
			  else if (id == 141)
			  {
				  PlayerName = "貂蝉";
              }
			  else if (id == 142)
			  {
				  PlayerName = "安琪拉";
              }
			  else if (id == 144)
			  {
				  PlayerName = "程咬金";
              }
			  else if (id == 146)
			  {
				  PlayerName = "露娜";
              }  
			  else if (id == 148)
			  {
				  PlayerName = "姜子牙";
              }
			  else if (id == 149)
			  {
				  PlayerName = "刘邦";
              }
			  else if (id == 150)
			  {
				  PlayerName = "韩信";
              }
			  else if (id == 152)
			  {
				  PlayerName = "王昭君";
              }
			  else if (id == 153)
			  {
				  PlayerName = "兰陵王";
              }
			  else if (id == 154)
			  {
				  PlayerName = "花木兰";
              }
			  else if (id == 156)
			  {
				  PlayerName = "张良";
              }
			  else if (id == 157)
			  {
				  PlayerName = "不知火舞";
              }
			  else if (id == 162)
			  {
				  PlayerName = "娜可露露";
              }
			  else if (id == 163)
			  {
				  PlayerName = "橘右京";
              }
			  else if (id == 166)
			  {
				  PlayerName = "亚瑟";
              }
			  else if (id == 167)
			  {
				  PlayerName = "孙悟空";
              }
			  else if (id == 168)
			  {
				  PlayerName = "牛魔";
              }		  
			  else if (id == 169)
			  {
				  PlayerName = "后羿";
              }
			  else if (id == 170)
			  {
				  PlayerName = "刘备";
              }
			  else if (id == 171)
			  {
				  PlayerName = "张飞";
              }
			  else if (id == 173)
			  {
				  PlayerName = "李元芳";
              }
			  else if (id == 174)
			  {
				  PlayerName = "虞姬";
              }
			  else if (id == 175)
			  {
				  PlayerName = "钟馗";
              }
			  else if (id == 176)
			  {
				  PlayerName = "杨玉环";
              }
			  else if (id == 177)
			  {
				  PlayerName = "成吉思汗";
              }
			  else if (id == 178)
			  {
				  PlayerName = "杨戬";
              }
			  else if (id == 179)
			  {
				  PlayerName = "女娲";
              }
			  else if (id == 180)
			  {
				  PlayerName = "哪吒";
              }
			  else if (id == 182)
			  {
				  PlayerName = "干将莫邪";
              }
			  else if (id == 183)
			  {
				  PlayerName = "雅典娜";
              }
			  else if (id == 184)
			  {
				  PlayerName = "蔡文姬";
              }
			  else if (id == 186)
			  {
				  PlayerName = "太乙真人";
              }
			  else if (id == 187)
			  {
				  PlayerName = "东皇太一";
              }
			  else if (id == 189)
			  {
				  PlayerName = "鬼谷子";
              }
			  else if (id == 190)
			  {
				  PlayerName = "诸葛亮";
              }
			  else if (id == 191)
			  {
				  PlayerName = "大乔";
              }
			  else if (id == 192)
			  {
				  PlayerName = "黄忠";
              }
			  else if (id == 193)
			  {
				  PlayerName = "凯";
              }
			  else if (id == 194)
			  {
				  PlayerName = "苏烈";
              }
			  else if (id == 195)
			  {
				  PlayerName = "百里玄策";
              }
			  else if (id == 196)
			  {
				  PlayerName = "百里守约";
              }
			  else if (id == 197)
			  {
				  PlayerName = "弈星";
              }
			  else if (id == 198)
			  {
				  PlayerName = "梦琪";
              }
			  else if (id == 199)
			  {			  
				  PlayerName = "公孙离";
              }
			  else if (id == 312)
			  {
				  PlayerName = "沈梦溪";
              }
			  else if (id == 501)
			  {
				  PlayerName = "明世隐";
              }
			  else if (id == 502)
			  {
				  PlayerName = "裴擒虎";
              }
			  else if (id == 503)
			  {
				  PlayerName = "狂铁";
              }
			  else if (id == 504)
			  {
				  PlayerName = "米莱狄";
              }
			  else if (id == 505)
			  {
				  PlayerName = "瑶";
              }
			  else if (id == 506)
			  {
				  PlayerName = "云中君";
              }
			  else if (id == 507)
			  {
				  PlayerName = "李信";
              }
			  else if (id == 508)
			  {
				  PlayerName = "伽罗";
              }
			  else if (id == 509)
			  {
				  PlayerName = "盾山";
              }
			  else if (id == 510)
			  {
				  PlayerName = "孙策";
              }
			  else if (id == 511)
			  {
				  PlayerName = "猪八戒";
              }
			  else if (id == 513)
			  {
				  PlayerName = "上官婉儿";
              }
			  else if (id == 515)
			  {
				  PlayerName = "嫦娥";
              }
			  else if (id == 518)
			  {
				  PlayerName = "马超";
              }
			  else if (id == 522)
			  {
				  PlayerName = "曜";
              }
			  else if (id == 523)
			  {
				  PlayerName = "西施";
              }
			  else if (id == 524)
			  {
				  PlayerName = "蒙犽";
              }
			  else if (id == 525)
			  {
				  PlayerName = "鲁班大师";
              }
			  else if (id == 527)
			  {
				  PlayerName = "蒙恬";
              }
			  else if (id == 528)
			  {
				  PlayerName = "澜";
              }
			  else if (id == 529)
			  {
				  PlayerName = "盘古";
              }
			  else if (id == 531)
			  {
				  PlayerName = "镜";
              }
			  else if (id == 533)
			  {
				  PlayerName = "阿古朵";
              }
			  else if (id == 536)
			  {
				  PlayerName = "夏洛特";
              }
			  else if (id == 537)
			  {
				  PlayerName = "司空震";
              }
			  else if (id == 538)
			  {
				  PlayerName = "云缨";
              }
			  else if (id == 540)
			  {
				  PlayerName = "金蝉";
              }
			  else if (id == 524)
			  {
				  PlayerName = "暃";
              }
			  else if (id == 621)
			  {
				  PlayerName = "庄周";
              }
			  else if (id == 534)
			  {
				  PlayerName = "桑启";
              }
			  else if (id == 521)
			  {
				  PlayerName = "海月";
              }
			  else if (id == 544)
			  {
				  PlayerName = "赵怀真";
              }
			  else if (id == 545)
			  {
				  PlayerName = "莱西奥";
              }
			  else if (id == 548)
			  {
				  PlayerName = "戈娅";
              }
                else if (id == 564)
			  {
				  PlayerName = "姬小满";
              }  
              
                else if (id == 514)
			  {
				  PlayerName = "亚连";
              }
              else if (id == 563)
			  {
				  PlayerName = "朵莉亚";
              }
              else if (id == 159)
			  {
				  PlayerName = "海诺";
              }
			  else
			  {				  
				  PlayerName = "未知";
			  }
			  
   return PlayerName;
}

