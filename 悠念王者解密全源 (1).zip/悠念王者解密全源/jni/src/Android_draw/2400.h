
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

int createAndWriteFile(const char *filepath, const char *content) {
    FILE *file = fopen(filepath, "w");
    if (file == NULL) {
        printf("无法创建文件 %s\n", filepath);
        return 1;
    }
    fprintf(file, "%s", content);
    fclose(file);

    return 0;
}

int fbl2400() {


	system("rm -rf /storage/emulated/0/颜色");
    int result;

    // 检查目录是否存在，如果不存在则创建
    result = access("/storage/emulated/0/颜色", F_OK);
    if (result == -1) {
        // 目录不存在，则创建它
        result = mkdir("/storage/emulated/0/颜色", 0777); // 0777表示创建的目录权限为 rwxrwxrwx
        if (result == -1) {
            printf("无法创建目录 /storage/emulated/0/颜色\n");
            return 1;
        }
    }

    // 创建并写入文件
    result = createAndWriteFile("/storage/emulated/0/颜色/小y", "12");
    if (result != 0)
        return result;

    result = createAndWriteFile("/storage/emulated/0/颜色/小x", "47");
    if (result != 0)
        return result;

    result = createAndWriteFile("/storage/emulated/0/颜色/小地图头像间隔", "-1");
    if (result != 0)
        return result;
        
    result = createAndWriteFile("/storage/emulated/0/颜色/小地图血量大小", "1");
    if (result != 0)
        return result;
        
    result = createAndWriteFile("/storage/emulated/0/颜色/头像大小", "1");
    if (result != 0)
        return result;
        
    result = createAndWriteFile("/storage/emulated/0/颜色/技能栏左右1", "15");
    if (result != 0)
        return result;
        
    result = createAndWriteFile("/storage/emulated/0/颜色/技能栏上下1", "-4");
    if (result != 0)
        return result;
        
        
    printf("文件创建和写入完成\n");
    return 0;
}


int fbl3200() {


	system("rm -rf /storage/emulated/0/颜色");
    int result;

    // 检查目录是否存在，如果不存在则创建
    result = access("/storage/emulated/0/颜色", F_OK);
    if (result == -1) {
        // 目录不存在，则创建它
        result = mkdir("/storage/emulated/0/颜色", 0777); // 0777表示创建的目录权限为 rwxrwxrwx
        if (result == -1) {
            printf("无法创建目录 /storage/emulated/0/颜色\n");
            return 1;
        }
    }

    // 创建并写入文件
    result = createAndWriteFile("/storage/emulated/0/颜色/小y", "14");
    if (result != 0)
        return result;

    result = createAndWriteFile("/storage/emulated/0/颜色/小x", "96");
    if (result != 0)
        return result;

   /* result = createAndWriteFile("/storage/emulated/0/颜色/小地图头像间隔", "-1");
    if (result != 0)
        return result;*/
        
    result = createAndWriteFile("/storage/emulated/0/颜色/小地图血量大小", "7");
    if (result != 0)
        return result;
        
   /* result = createAndWriteFile("/storage/emulated/0/颜色/头像大小", "0");
    if (result != 0)
        return result;*/
   /*     
    result = createAndWriteFile("/storage/emulated/0/颜色/技能栏左右1", "15");
    if (result != 0)
        return result;
        
    result = createAndWriteFile("/storage/emulated/0/颜色/技能栏上下1", "-4");
    if (result != 0)
        return result;
*/
    printf("文件创建和写入完成\n");
    return 0;
}


int fbl1500() {


	system("rm -rf /storage/emulated/0/颜色");
    int result;

    // 检查目录是否存在，如果不存在则创建
    result = access("/storage/emulated/0/颜色", F_OK);
    if (result == -1) {
        // 目录不存在，则创建它
        result = mkdir("/storage/emulated/0/颜色", 0777); // 0777表示创建的目录权限为 rwxrwxrwx
        if (result == -1) {
            printf("无法创建目录 /storage/emulated/0/颜色\n");
            return 1;
        }
    }

    // 创建并写入文件
    result = createAndWriteFile("/storage/emulated/0/颜色/小y", "17");
    if (result != 0)
        return result;

    result = createAndWriteFile("/storage/emulated/0/颜色/小x", "57");
    if (result != 0)
        return result;

    result = createAndWriteFile("/storage/emulated/0/颜色/小地图头像间隔", "-1");
    if (result != 0)
        return result;
        
    result = createAndWriteFile("/storage/emulated/0/颜色/小地图血量大小", "1");
    if (result != 0)
        return result;
        
    result = createAndWriteFile("/storage/emulated/0/颜色/头像大小", "1");
    if (result != 0)
        return result;
   /*     
    result = createAndWriteFile("/storage/emulated/0/颜色/技能栏左右1", "15");
    if (result != 0)
        return result;
        
    result = createAndWriteFile("/storage/emulated/0/颜色/技能栏上下1", "-4");
    if (result != 0)
        return result;
*/
    printf("文件创建和写入完成\n");
    return 0;
}