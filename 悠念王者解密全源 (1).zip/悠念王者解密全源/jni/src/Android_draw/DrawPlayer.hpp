#include "include.h"
#include "IsCharacter.h"
//#include "循环.h"

#define BYTE4 0x00000004
#define BYTE8 0x00000008
#define BYTE16 0x00000010
#define BYTE10 0x000000A
#define BYTE64 0x00000040
#define BYTE1024 0x00000400
uintptr_t unity;
uintptr_t unitybss;
uintptr_t GameCore;
uintptr_t GameCorebss;
uintptr_t il2cpp;
uintptr_t il2cppbss;
uintptr_t 对象坐标;
static uint64_t lil2cpp_base = 0;
static uint64_t libGame_base = 0;
static uint64_t libunity_base = 0;
static uint64_t libtersafe_base = 0;
uint64_t MatrixAddress = 0;//初始化矩阵地址
float isGames;//储存矩阵的值
int foeComp;//敌方阵营
int rientation = 0;//对局方向
int AroundNumbers = 0;//人头数量
int 视野=0;
int 自身视野=0;
bool 坐标解密1=false;
bool 坐标解密2=false;
bool 坐标解密3 = false;
bool 坐标解密4 = false;
long coordinatex, coordinatey;
//int 屏幕x;
//int 屏幕y;
long rotatingdraw=0;
/////////内核读写/////////
#include <sys/fcntl.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include <ctype.h>
#include <fstream>
#include <sstream>
#include <sys/fcntl.h>
#include <sys/ioctl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <map>
#include <vector>
#include <algorithm>
#include <dirent.h>
#include <unistd.h>
#include <chrono>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/kdev_t.h>
#include <sys/sysmacros.h>
#include <iostream>


ImTextureID FloatBall;

void DrawLogo(ImVec2 center, float size)
{
	ImGui::SetCursorPos({0, 180});
	ImDrawList *draw_list = ImGui::GetWindowDrawList();
	draw_list->AddImage(FloatBall,{center.x - size / 2, center.y - size / 2},{center.x + size / 2, center.y + size / 2});
	
}






class c_driver {










	private:
	int has_upper = 0;
	int has_lower = 0;
	int has_symbol = 0;
	int has_digit = 0;
	int fd;
	pid_t pid;

	typedef struct _COPY_MEMORY {
		pid_t pid;
		uintptr_t addr;
		void* buffer;
		size_t size;
	} COPY_MEMORY, *PCOPY_MEMORY;

	typedef struct _MODULE_BASE {
		pid_t pid;
		char* name;
		uintptr_t base;
	} MODULE_BASE, *PMODULE_BASE;

	enum OPERATIONS {
		OP_INIT_KEY = 0x800,
		OP_READ_MEM = 0x801,
		OP_WRITE_MEM = 0x802,
		OP_MODULE_BASE = 0x803,
	};
		int symbol_file(const char *filename){
	int length = strlen(filename);
		for (int i = 0; i < length; i++){
		if (isupper(filename[i])){
				has_upper = 1;
			}
			else if (islower(filename[i])){
				has_lower = 1;
			}
			else if (ispunct(filename[i])){
				has_symbol = 1;
			}
			else if (isdigit(filename[i])){
				has_digit = 1;
			}
		}

		return has_upper && has_lower && !has_symbol && !has_digit;
	}
	bool StrAlpha(const char *str){
	       for(int i = 0;i<6;i++){
	           if(!isalpha(str[i])){
	             return false;
	           }
	       }
	       return true;
	}
	int OpenFd(){


	//sleep(3);
        DIR * dir;
    	struct dirent * ptr;
    	struct stat info;
    	dir = opendir("/proc");
    	ssize_t len;
    	char path[256];
    	char buffer[256];
    	char fd_path[256];
    	char fd_buffer[256];
    	char dev_path[256];
        char data_path[128];
    	int ID;
    	int PPID;
    	auto start = std::chrono::high_resolution_clock::now();  // 获取起始时间
    	while((ptr = readdir(dir)) != NULL){
    	   if(ptr->d_type == DT_DIR){
    	     sprintf(buffer,"/proc/%d/exe",atoi(ptr->d_name));
    		 //printf("文件夹: %s\n  路径: %s",ptr->d_name,buffer);
    	     len = readlink(buffer, path, sizeof(path) - 1);
    	     if (len != -1)   path[len] = '\0';
    	     char* stres = strrchr(path,'(deleted)');
    	     if(stres != NULL){
    	       sscanf(path, "/data/%s", &data_path);
    	       if(StrAlpha(data_path)){
    		     sscanf(buffer,"/proc/%d/exe",&PPID);
    		 //    printf("[+] 软链: %s  PID: %d\n", path, PPID);
    		     for(int i = 3;i<5;i++){
    		         sprintf(fd_path,"/proc/%d/fd/%d",PPID,i);
    		         len = readlink(fd_path, fd_buffer, sizeof(fd_buffer) - 1);
    		         char* stress = strrchr(fd_buffer,'(deleted)');
    		         if(stress != NULL){
    		            int fd_file = open(fd_path, O_RDONLY);
    		            if (fd_file == -1) {
    		               perror("open");
    		               close(fd_file);
    		               return EXIT_FAILURE;
    		            }
    		            if (fstat(fd_file, &info) == -1) {
    		               perror("fstat");
    		               close(fd_file);
    		               return 0;
    		            }
    		            sscanf(fd_buffer,"%s (deleted)", dev_path);
    		         //   printf("[*] 设备路径: %s  设备 ID: %lu\n", dev_path, info.st_dev);
    		         //   printf("[*] 主设备号: %lu\n", major(info.st_rdev));
    		   //         printf("[*] 次设备号: %lu\n", minor(info.st_rdev));
    		            if(access(dev_path,F_OK) == 0){  //检查文件是否存在
    		               ID = open(dev_path,O_RDWR);
    		               if(ID != -1){
    		               //  printf("[+] 驱动挂载成功\n");
    		                 if(unlink(dev_path) == 0) {
    		                   // printf("[+] 驱动守护中\n");
    		                    auto end = std::chrono::high_resolution_clock::now();  // 获取结束时间
    		                    float elapsed_ns = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count(); //获毫秒
    		                    //printf("[+] 读取驱动用时: %.f ms\n", elapsed_ns);
    		                    return ID;
    		                    //return 0;
    		                 }
    		               }
    		            }  else { //驱动已经隐藏
    		              // printf("[+] 驱动已隐藏创建驱动中\n");
    		               mode_t mode = S_IFCHR | 0666; // 创建一个命名管道，权限为读写
    		               dev_t dev = makedev(major(info.st_rdev), minor(info.st_rdev));
    		               if(mknod(dev_path, mode, dev) != -1){
    		                 // printf("[+] mknod : %d 成功\n", major(info.st_rdev));
    		               }
    		               ID = open(dev_path,O_RDWR);
    		               if(ID != -1){
    		                  printf("[+] 驱动挂载成功\n\n");
    		                  if(unlink(dev_path) != -1){
    		                   // printf("[+] 驱动守护中\n");
    		                    auto end = std::chrono::high_resolution_clock::now();  // 获取结束时间
    		                    float elapsed_ns = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count(); //获毫秒
    		                    //printf("[+] 读取驱动用时: %.f ms\n", elapsed_ns);
    		                    return ID;
    		                  }
    		               }
    		            }
    		            close(fd_file);
    		            break;
    		         }
    		     }
    		     break;
    		   }
    		 }
    	   }
    	}
    	closedir(dir);
    	printf("[-] 驱动挂载失败\n");
    	exit(1);
    	return -1;
   }
	public:
	c_driver() {
	
      fd= OpenFd();
	}
	~c_driver() {
		//wont be called
		if (fd > 0)
			
			close(fd);
	}

	void initialize(pid_t pid) {
		this->pid = pid;
	}

	bool init_key(char* key) {
		char buf[0x100];
		strcpy(buf,key);
		if (ioctl(fd, OP_INIT_KEY, buf) != 0) {
			return false;
		}
		return true;
	}

	bool read(uintptr_t addr, void *buffer, size_t size) {
	addr=addr&0xFFFFFFFFFFFF;
		COPY_MEMORY cm;

		cm.pid = this->pid;
		cm.addr = addr;
		cm.buffer = buffer;
		cm.size = size;

		if (ioctl(fd, OP_READ_MEM, &cm) != 0) {
			return false;
		}
		return true;
	}

	bool write(uintptr_t addr, void *buffer, size_t size) {
		COPY_MEMORY cm;

		cm.pid = this->pid;
		cm.addr = addr;
		cm.buffer = buffer;
		cm.size = size;

		if (ioctl(fd, OP_WRITE_MEM, &cm) != 0) {
			return false;
		}
		return true;
	}

	template <typename T>
	T read(uintptr_t addr) {
		T res;
		if (this->read(addr, &res, sizeof(T)))
			return res;
		return {};
	}

	template <typename T>
	bool write(uintptr_t addr,T value) {
		return this->write(addr, &value, sizeof(T));
	}

	uintptr_t getModuleBase(char* name) {
		MODULE_BASE mb;
		char buf[0x100];
		strcpy(buf,name);
		mb.pid = this->pid;
		mb.name = buf;

		if (ioctl(fd, OP_MODULE_BASE, &mb) != 0) {
			return 0;
		}
		return mb.base;
	}
};

static c_driver *driver = new c_driver();

/////////完/////////////
/////////完/////////////




pid_t get_name_pid(char* name) {
    FILE* fp;
    pid_t pid;
    char cmd[0x100] = "pidof ";

    strcat(cmd, name);
    fp = popen(cmd,"r");
    fscanf(fp,"%d", &pid);
    pclose(fp);
    return pid;
}

struct Coord {
    float X;//X轴
    float Y;//Y轴
    float W;
    float H;
};
struct DynamicData {
    struct Coord coord;//获取xy坐标
};



struct HeroTemp {
    struct Coord coord;//获取xy坐标
    int Hp;//当前血量
    int MaxHp;//最大血量
    int Id;//英雄id
    int Space;//大招cd
    int Skill;//召唤师技能cd
    int camp;//阵营id
    int HC;//回城
    int TB;//图标
    int confound;//坐标混淆
};
/**
 * 获取野怪xy和刷新时间
 */
struct Pve {
    uint64_t X;//X坐标地址
    uint64_t Y;//Y坐标地址
    uint64_t cd;//刷新时间
    uint64_t cc;
    uint64_t maxcd;
};
/**
 * 获取野怪xy和刷新时间
 */
 
 struct PveTemp {
    struct Coord coord;//获取xy坐标
    int cd;//刷新时间
    int maxcd;
};

/**
 * 获取兵线xy
 */
struct Pvc {
    uint64_t X;//X坐标地址
    uint64_t Y;//Y坐标地址
};
/**
 * 单个兵线
 */
struct CeTemp {
    struct Coord coord;//获取xy坐标
    int cd;
};

typedef struct {
    float Matrix[BYTE16];//相机矩阵
    struct HeroTemp heroTemp[BYTE16];//储存单个英雄
    struct DynamicData DynamicData[BYTE16];//储存单个英雄大地图
    struct Pve pve[BYTE1024];//储存野怪
    struct PveTemp pveTemp[BYTE1024];//储存野怪
    struct CeTemp CeTemp[BYTE1024];//储存兵线
    struct Pvc pvc[BYTE1024];//储存兵线
    int xbsl;//小兵数量
} DataTable;


DataTable dataTable;//游戏数据表


    const static ImColor Paint_purple = ImColor(255, 0, 255);  //紫色
    const static ImColor Paint_red = ImColor(255, 0, 0);       //红色
    const static ImColor Paint_white = ImColor(255, 255, 255); //白色
    const static ImColor Paint_lightblue = ImColor(0, 255, 255);   //浅蓝色
    const static ImColor Paint_yellow = ImColor(255, 255, 0);  //黄色
    const static ImColor Paint_green = ImColor(0, 255, 0);  //绿色

double Wwra = 0;    //转小地图算法




 struct Coord map_coord = {0};/*实际地图坐标*/
    struct Coord map_buff = {0};/*实际地图坐标*/


      
long coorpage = 0;
long offset = 0;

long cooroffest = 0;

long getcoor(long addr)
{
//////////////

	
//空壳解密
if(坐标解密4)
	{
return 对象坐标;
	}
	
//空壳解密
if(坐标解密3)
	{
return 对象坐标;
	}
////////////////
	
	
    if(坐标解密2){

	long 对象坐标=driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(addr + 0x240) + 0x10)) + 0x10);
  
    long coorb=driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(addr + 0x160) + 0x68) + 0xb0)+0x48);

	long encrypt = 对象坐标 & (~(PAGE_SIZE - 1));
	//if (encrypt == (coorb & (~(PAGE_SIZE - 1))))
   if (encrypt == 对象坐标)
	{

		if (encrypt != coorpage and encrypt != 0)
		{
			long start = 0, end = 0;
			char line[1024] = { 0 };
			char path[128];
			sprintf(path, "/proc/%d/maps", pid);
			FILE *p = fopen(path, "r");

			if (p)
			{
				while (fgets(line, sizeof(line), p))
				{
					if (strstr(line, "[anon:objects_external_alloc]") != NULL)
					{
						sscanf(line, "%lx-%lx", &start, &end);
						for (int i = 0; i < 5; i++)
						{
							long coor = start + 0x5000 * i + 0x688;
							if (coor > end)
								break;
							if (driver->read<uint64_t>(coor) == encrypt)
							{
								long page = driver->read<uint64_t>(coor + 0x8);
								cooroffest = page - encrypt + driver->read<int>(coor + 0x10);
							}

						}
					}
				}
				fclose(p);
			}
			coorpage = encrypt;
		}
	}
	if (encrypt == coorpage)
	{
		对象坐标 = 对象坐标 + cooroffest;
		ImGui::GetForegroundDrawList()->AddText(ImVec2(0, 1080-30), Paint_red, "      当前坐标已被加密(方案二)");
	}else{
	ImGui::GetForegroundDrawList()->AddText(ImVec2(0, 1080-30), Paint_green, "      当前坐标未加密(方案二)");
	
	}

	return 对象坐标;
	
	}
	
	
	
	
	
	if(坐标解密1){
	
	long 对象坐标=driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(addr + 0x240) + 0x10)) + 0x10);
    long encrypt = 对象坐标&(~(4096 - 1));
  //  ImGui::GetForegroundDrawList()->AddText(ImVec2(0, 1080-30), Paint_green, "      当前坐标未加密");
   
if (encrypt == 对象坐标)
    {
            if (encrypt != coorpage && encrypt != 0 && cooroffest == 0){
            for (int i = 1; i <= 4096 * 2000; i++){
            long start = encrypt - 4096 * i;
            //long pointerValue= driver->read<uint64_t>(start+0x55B8);
         
           if (driver->read<uint64_t>(start + 0xF688) == encrypt){                  
                     long coor = start + 0xF690;
                     cooroffest = driver->read<uint64_t>(coor) - encrypt + driver->read<int>(coor +0x8);
                    // coorpage = encrypt;
                     break;
            }
            
            if (driver->read<uint64_t>(start + 0x55B8) == encrypt){
                     long coor = start + 0x55C0;
                     cooroffest = driver->read<uint64_t>(coor) - encrypt + driver->read<int>(coor +0x8);
                    // coorpage = encrypt;
                     break;
            }
       }       
             coorpage=encrypt; 
    }
            
}
         
         

    if (encrypt == coorpage)
    {
        对象坐标=对象坐标+cooroffest;
        ImGui::GetForegroundDrawList()->AddText(ImVec2(0, 1080-30), Paint_red, "      当前坐标已被加密(方案一)");
    }else{
 
 
 ImGui::GetForegroundDrawList()->AddText(ImVec2(0, 1080-30), Paint_green, "      当前坐标未加密(方案一)");
 
 }
   // printf("%p\n", (void*)(driver->read<unsigned char>(对象坐标 + 0xD)));
    
    return 对象坐标;
	}
	return 对象坐标;
}

/*


if 视野 == 1 then
         local encrypt = PosPtr & -(4096 - 1)
         if encrypt == PosPtr then
             if encrypt ~= coorpage and encrypt ~= 0 and cooroffest == 0 then
                 for i = 1, 4096 * 2000 do
                          local start = encrypt - 4096 * i
                     if GetB4(start + 0x55B8) == encrypt then
                         local coor = start + 0x55C0
                         cooroffest = GetB4(coor) - encrypt + Biu.getint(coor + 0x8)
                         break
                     end
                 end
                 coorpage = encrypt
             end
         end

         if encrypt == coorpage then
             PosPtr = PosPtr + cooroffest
         end
     end
*/


void DrawInit() {
    pid = get_name_pid((char*)"com.tencent.tmgp.sgame");
    driver->initialize(pid);
    if (pid == 0 || pid == -1) {
        puts("先打开游戏");
        exit(1);
    }
    libGame_base = driver->getModuleBase("libGameCore.so");
    lil2cpp_base = driver->getModuleBase("libil2cpp.so");
    libunity_base = driver->getModuleBase("libunity.so");            
    libtersafe_base = driver->getModuleBase("libtersafe.so");
            
            
    ::yxpx = abs_ScreenX;     
    ::yxpy = abs_ScreenY;     
    
    

    
    /*
    if (fenblxx == 0) {
        int x1 = screen_x < screen_y ? screen_x : screen_y;
        int y1 = screen_x < screen_y ? screen_y : screen_x;
        if (yxpx < yxpy) {
            yxpx=x1;
            yxpy=y1;
        } else {
            yxpy=x1;
            yxpx=y1;
        }
    }
    */
    
       
}
 
 Coord CalMatrixMem(struct Coord coor, const float Matrix[]) {
    struct Coord points = {0};
    float XM = coor.X / 1000.0f;
    float ZM = coor.Y / 1000.0f;
    if(Matrix[11]&&Matrix[15]&&Matrix[0]&&Matrix[12]&&Matrix[9]&&Matrix[13]&&Matrix[1]&&Matrix[5] &&Matrix[9]&&Matrix[13]){
    float radio = (float)fabs(ZM * Matrix[11] + Matrix[15]);
    points.X = 0.0f, points.Y = 0.0f, points.W = 0.0f, points.H = 0.0f;
    if (radio > 0) {
        points.X = yxpx/2 + (XM * Matrix[0] + Matrix[12]) / radio * yxpx/2;
        points.Y = yxpy/2 - (ZM * Matrix[9] + Matrix[13]) / radio * yxpy/2;
        points.W = yxpy/2 - (XM * Matrix[1] + 4.0f * Matrix[5] + ZM * Matrix[9] + Matrix[13]) / radio * yxpy/2;
        points.H = ((points.Y - points.W) / 2.0f);
    }
    return points;
    }
}
    
    
/**
 * 大地图转小地图坐标
 * @param foe
 * @return
 */
    





void DrawPlayer()
{
const static float TXdx = yxpy * 0.017534f; //(头像)圈大小(22.5)半径
      const static float soldiers_dx = yxpy * (double)0.001851851851851851; //(兵)大小(2.0f)半径
    const static float CDjs_X = yxpx * 0.337250f; //绘制cd起
       const static float CDjs_Y = yxpy * 0.006481f; //绘制cd起点Y(7)
    const static float intervalcdX = yxpx * 0.025200f; //60(cd左右间隔)
    const static float intervalcdY = yxpy * 0.032407f; //35(cd上下间隔)

    
    
    const static float skills_dx = yxpy * (double)0.006481481481481481;
    const static float skills_txt_dx = skills_dx * 5.0f;    //技能CD文字大小
    Wwra=yxpy / 10.9f * (1.574074075+(jiange*0.01));   // 间隔
    
    long temp = driver->read<uint64_t>(lil2cpp_base+0x8c470D8);//8F547A8
    
    MatrixAddress = driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(temp + 0xA0) + 0x0) + 0x10) + 0xC0;
    isGames = driver->read<float>(MatrixAddress);
    //判断敌方阵营id
    /*  ?  :   三目运算符  如果大于0就返回2 否则返回1 */
    foeComp = isGames > 0 ? 2 : 1;
    //LOGE("foeComp:%d",foeComp);
    //判断阵营，获取算法，判断方向
    rientation = foeComp == 1 ? -1 : 1;
    
        for (int i = 0; i < 16; i++)
        {
        
            dataTable.Matrix[i] = driver->read<float>(MatrixAddress + i * 4);
        }
    
    
    
    //ImGui::GetBackgroundDrawList()->AddImage(createTexture1("/storage/emulated/0/105.png").textureId, ImVec2(100-25, 100-25), ImVec2(100+25, 100+25));

    long temp1 = driver->read<uint64_t>(libGame_base +  0x3A3B660);
 //   printf("temp1 %f \n",temp1);
                                                                                                         long bingxiang8 = driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(libGame_base  + 0x3A3B660) +0x48)+0xD8);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
    long bingxiang1 = temp1 + 0x150;
  
    AroundNumbers =12;

int opop=0;
    
        for (int i = 0; i < AroundNumbers; i++)
        {
            int ndh = i * 0x18;
    
    
       //     long bingxiang6 =driver->read<uint64_t>( driver->read<uint64_t>(driver->read<uint64_t>(bingxiang1) +0x60 )+ndh);
            
            		long bingxiang6 = driver->read<uint64_t>(driver->read<uint64_t>(bingxiang1  +  i * 0x18)+0x68);
            		
        int pand = 1;
        
        if (pand > 0)
            {

    int zhengxing = driver->read<int>(bingxiang6 + 0x3C);

if(zhengxing==foeComp){



        // //////头像id↓代码


                    dataTable.heroTemp[i].Id = driver->read<uint64_t>(bingxiang6 + 0x30);
                  
dataTable.heroTemp[i].Hp =driver->read<int>(driver->read<uint64_t>(bingxiang6 + 0x160) + 0xa0);  // 当前血量

    dataTable.heroTemp[i].MaxHp = driver->read<int>(driver->read<uint64_t>(bingxiang6 + 0x160) + 0xa8);

dataTable.heroTemp[i].HC =  driver->read<int>(driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(bingxiang6 +0x148) + 0x168) + 0x118) + 0x20);





if(zhengxing==2){
				 视野 = driver->read<int>(driver->read<uint64_t>(driver->read<uint64_t>(bingxiang6 + 0x258) + 0x68)+0x1c);
				}else{
				 视野 = driver->read<int>(driver->read<uint64_t>(driver->read<uint64_t>(bingxiang6 + 0x258) + 0x68)+0x3c);
				}
				
				对象坐标=getcoor(bingxiang6);
				
				if(视野 ==257) {
				float 坐标x = driver->read<float>(bingxiang6 - 0x278)*1000;//坐标输出的坐
				float 坐标y = driver->read<float>(bingxiang6 - 0x270)*1000;//坐标输出的坐
			    
			    if (坐标x && 坐标y) {
				 dataTable.heroTemp[i].coord.X =(float)坐标x;
				 dataTable.heroTemp[i].coord.Y =(float)坐标y;
				 }
				} else {
				 float 坐标x= (float)driver->read<int>(对象坐标 + 0x0);
				 float 坐标y= (float)driver->read<int>(对象坐标 + 0x8);
			    if (坐标x && 坐标y) {
				 dataTable.heroTemp[i].coord.X =(float)坐标x;
				 dataTable.heroTemp[i].coord.Y =(float)坐标y;
				 }
				}


dataTable.DynamicData[i].coord.X = (dataTable.heroTemp[i].coord.X * rientation * Wwra / 50000.0f + Wwra);
dataTable.DynamicData[i].coord.Y = (dataTable.heroTemp[i].coord.Y * rientation * Wwra / 50000.0f * -1 + Wwra);
 
float pos_x = dataTable.DynamicData[i].coord.X + SmallMapX+94;
float pos_y = dataTable.DynamicData[i].coord.Y + SmallMapY+7;

map_coord = CalMatrixMem(dataTable.heroTemp[i].coord, dataTable.Matrix);
  map_coord.X = map_coord.X + SmallHPX;
map_coord.Y = map_coord.Y + SmallHPY;


        float hp1 = dataTable.heroTemp[i].Hp * 100 / dataTable.heroTemp[i].MaxHp;

    float aa = hp1*3.6;
                  //   ImColor 血量颜色;
                //     血量颜色 = ImColor(10,240,10,210);
                
                
                ImTextureID handId;
                if(dataTable.heroTemp[i].Id>100&&dataTable.heroTemp[i].Id<600){
            
                handId =reinterpret_cast<ImTextureID>(贴图1.头像[dataTable.heroTemp[i].Id].textureId);
    }else{ 
        handId=reinterpret_cast<ImTextureID>(贴图1.头像[0].textureId);
    }
                
                
                if(aa>0){
                    
    if(血量){

                    //小头像血量
   ImGui::GetForegroundDrawList()->AddCircleArc({pos_x, pos_y},21+xiaodituxue, ImVec2(0, 360), Paint_white,  0, 5.5f);//白底背景
           if(视野==257){
   ImGui::GetForegroundDrawList()->AddCircleArc({pos_x, pos_y},21+xiaodituxue, ImVec2(0, aa), 颜色配置.血量颜色,  0, 5.5f);//红色血圈
   }else{
   ImGui::GetForegroundDrawList()->AddCircleArc({pos_x, pos_y},21+xiaodituxue, ImVec2(0, aa), Paint_purple,  0, 5.5f);//红色血圈//紫色无视野
   }
    }       
   
    rotatingdraw=rotatingdraw+3;  
    if(地图){
   //小头像
                    ImGui::GetForegroundDrawList()->AddImage( handId!= NULL ?  handId: 0 , {(int)pos_x - TXdx-touxiangdaxiao, (int)pos_y - TXdx-touxiangdaxiao}, {(int)pos_x + TXdx+touxiangdaxiao, (int)pos_y + TXdx+touxiangdaxiao});
                    
                        if(dataTable.heroTemp[i].HC == 1){       
ImGui::GetForegroundDrawList()->AddCircleArc({pos_x,pos_y},21+xiaodituxue,ImVec2(0+rotatingdraw,20+rotatingdraw),Paint_lightblue,9.5f,5.5f);
ImGui::GetForegroundDrawList()->AddCircleArc({pos_x,pos_y},21+xiaodituxue,ImVec2(20+rotatingdraw,40+rotatingdraw),Paint_purple,9.5f,5.5f);
ImGui::GetForegroundDrawList()->AddCircleArc({pos_x,pos_y},21+xiaodituxue,ImVec2(40+rotatingdraw,60+rotatingdraw),颜色配置.血量颜色,9.5f,5.5f);//顶上头像颜色
  
   }
}
                    
   if(自身判断){

   if(zhengxing==2){
				 自身视野 = driver->read<int>(driver->read<uint64_t>(driver->read<uint64_t>(bingxiang8 + 0x258) + 0x68)+0x3c);
				}else{
				 自身视野 = driver->read<int>(driver->read<uint64_t>(driver->read<uint64_t>(bingxiang8 + 0x258) + 0x68)+0x1c);
				}


	if(自身视野 ==257) {


ImGui::GetForegroundDrawList()->AddText(ImVec2(屏幕x, 屏幕y), Paint_red, "      [暴露]");
}
else{
ImGui::GetForegroundDrawList()->AddText(ImVec2(屏幕x, 屏幕y), Paint_green, "      [安全]");
}

   
   }
   
   
   
   if(方框){
   
         
               

                           
                                 
                                       
                                             
                                                   
                                                         
                                                               
                                                                     
                                                                           
                                                                                 
                                                                                       
                                                                                                   
   if(视野==257){
      if(视野方框){
      float current_hp_percentage = (float)dataTable.heroTemp[i].Hp / (float)dataTable.heroTemp[i].MaxHp;
      if (current_hp_percentage > 0.3f){
// 绘制外部方框
ImGui::GetForegroundDrawList()->AddRect(ImVec2((int)map_coord.X - (map_coord.H*0.5f), (int)map_coord.Y - (map_coord.H*1.32f)), ImVec2((int)map_coord.X + (map_coord.H*0.5), (int)map_coord.Y + (map_coord.H*0.2f)), 颜色配置.方框颜色, 0.0f, 0, 2.0f); //方框[ ]

// 绘制内部方框，覆盖外部方框
ImGui::GetForegroundDrawList()->AddRectFilled(ImVec2((int)map_coord.X - (map_coord.H*0.5f) + 2.0f, (int)map_coord.Y - (map_coord.H*1.32f) + 2.0f), ImVec2((int)map_coord.X + (map_coord.H*0.5f) - 2.0f, (int)map_coord.Y + (map_coord.H*0.2f) - 2.0f), ImColor(155, 155, 155, 78));//方框内部填充

//在方框内部绘制斜线网格线


   
   //方框里头像
       ImGui::GetForegroundDrawList()->AddImage(handId!= NULL ?  handId: 0, {(int)map_coord.X - (map_coord.H*0.2f), (int)map_coord.Y - (map_coord.H*0.2f)+ (-map_coord.H*1.0f)}, {(int)map_coord.X + (map_coord.H*0.2f), (int)map_coord.Y + (map_coord.H*0.2f)+ (-map_coord.H*1.0f)});
         
       
       //方框里血量
                    ImGui::GetForegroundDrawList()->AddCircleArc(ImVec2((int)map_coord.X,(int) map_coord.Y+ (-map_coord.H*1.0f)),(map_coord.H*0.22f)>0 ? (map_coord.H*0.22f) : 1, ImVec2(0, 360), Paint_white,  0, 5.5f);//白底背景
                    ImGui::GetForegroundDrawList()->AddCircleArc(ImVec2((int)map_coord.X, (int)map_coord.Y+ (-map_coord.H*1.0f)),(map_coord.H*0.22f)>0 ? (map_coord.H*0.22f) : 1, ImVec2(0, aa), 颜色配置.血量颜色,  0, 5.5f);//红色血圈
                    
                    }else{
                    
                    
                    ImGui::GetForegroundDrawList()->AddRect(ImVec2((int)map_coord.X - (map_coord.H*0.5f), (int)map_coord.Y - (map_coord.H*1.32f)), ImVec2((int)map_coord.X + (map_coord.H*0.5), (int)map_coord.Y + (map_coord.H*0.2f)), 颜色配置.血量颜色, 0.0f, 0, 2.0f); //方框[ ]

// 绘制内部方框，覆盖外部方框
ImGui::GetForegroundDrawList()->AddRectFilled(ImVec2((int)map_coord.X - (map_coord.H*0.5f) + 2.0f, (int)map_coord.Y - (map_coord.H*1.32f) + 2.0f), ImVec2((int)map_coord.X + (map_coord.H*0.5f) - 2.0f, (int)map_coord.Y + (map_coord.H*0.2f) - 2.0f), ImColor(255, 0, 0, 78));//方框内部填充

//在方框内部绘制斜线网格线


   
   //方框里头像
       ImGui::GetForegroundDrawList()->AddImage(handId!= NULL ?  handId: 0, {(int)map_coord.X - (map_coord.H*0.2f), (int)map_coord.Y - (map_coord.H*0.2f)+ (-map_coord.H*1.0f)}, {(int)map_coord.X + (map_coord.H*0.2f), (int)map_coord.Y + (map_coord.H*0.2f)+ (-map_coord.H*1.0f)});
         
       
       //方框里血量
                    ImGui::GetForegroundDrawList()->AddCircleArc(ImVec2((int)map_coord.X,(int) map_coord.Y+ (-map_coord.H*1.0f)),(map_coord.H*0.22f)>0 ? (map_coord.H*0.22f) : 1, ImVec2(0, 360), Paint_white,  0, 5.5f);//白底背景
                    ImGui::GetForegroundDrawList()->AddCircleArc(ImVec2((int)map_coord.X, (int)map_coord.Y+ (-map_coord.H*1.0f)),(map_coord.H*0.22f)>0 ? (map_coord.H*0.22f) : 1, ImVec2(0, aa), 颜色配置.血量颜色,  0, 5.5f);//红色血圈
                    
                    }
                    
                    
                    
                    

            
                    
                    
                    
                    
                 /*   float max_hp_percentage = 1.0f;
							//	float current_hp_percentage = (float)dataTable.heroTemp[i].Hp / (float)dataTable.heroTemp[i].MaxHp;
								float bar_width = map_coord.H * 0.1f;  //血条宽度
								float bar_height = map_coord.H * 1.2f;  //血条长度
								float corner_radius = 5.0f;

								// 绘制最大血量条边框
								/*ImGui::GetForegroundDrawList()->AddRect(
									ImVec2((int)map_coord.X-8- bar_width / 2 - (-map_coord.H*0.65f), (int)map_coord.Y - (map_coord.H*1.35f)),
									ImVec2((int)map_coord.X-8 + bar_width / 2 - (-map_coord.H*0.65f), (int)map_coord.Y + bar_height - (map_coord.H*1.05f)),
									Paint_white,
									corner_radius
								);*/

								// 绘制最大血量条填充
							/*	ImGui::GetForegroundDrawList()->AddRectFilled(
									ImVec2((int)map_coord.X-8 - bar_width / 2 + corner_radius - (-map_coord.H*0.65f), (int)map_coord.Y + corner_radius - (map_coord.H*1.35f)),
									ImVec2((int)map_coord.X-8 + bar_width / 2 - corner_radius - (-map_coord.H*0.65f), (int)map_coord.Y + bar_height - corner_radius - (map_coord.H*1.05f)),
									Paint_white,
									corner_radius
								);

								// 计算当前血量条的填充高度和起始位置
								float current_hp_fill_height = bar_height * current_hp_percentage;
								float fill_correction_factor = 1.32f;  // 初始修正因子为1.35

								// 根据敌人剩余血量百分比动态调整修正因子的值
								if (current_hp_percentage <= 0.85f) {
									fill_correction_factor = 1.05f;
								}

								float current_hp_fill_start_y = (int)map_coord.Y + bar_height - current_hp_fill_height - (map_coord.H * fill_correction_factor);

								// 绘制当前血量条填充
								ImGui::GetForegroundDrawList()->AddRectFilled(
									ImVec2((int)map_coord.X-8 - bar_width / 2 + corner_radius - (-map_coord.H * 0.65000000f), current_hp_fill_start_y),
									ImVec2((int)map_coord.X -8+ bar_width / 2 - corner_radius - (-map_coord.H * 0.65f), (int)map_coord.Y + bar_height - (map_coord.H * 1.05f)),
									颜色配置.血量颜色,
									corner_radius
								);
                    
                    */
                    
                    
                    
                    
                    
                    
                    
                    
                    
      
      }
   }else{
  //百分比30方框判断
  float current_hp_per = (float)dataTable.heroTemp[i].Hp / (float)dataTable.heroTemp[i].MaxHp;
          if (current_hp_per > 0.35f){
// 绘制外部方框
ImGui::GetForegroundDrawList()->AddRect(ImVec2((int)map_coord.X - (map_coord.H*0.5f), (int)map_coord.Y - (map_coord.H*1.32f)), ImVec2((int)map_coord.X + (map_coord.H*0.5), (int)map_coord.Y + (map_coord.H*0.2f)), 颜色配置.方框颜色, 0.0f, 0, 2.0f); //方框[ ]

// 绘制内部方框，覆盖外部方框
ImGui::GetForegroundDrawList()->AddRectFilled(ImVec2((int)map_coord.X - (map_coord.H*0.5f) + 2.0f, (int)map_coord.Y - (map_coord.H*1.32f) + 2.0f), ImVec2((int)map_coord.X + (map_coord.H*0.5f) - 2.0f, (int)map_coord.Y + (map_coord.H*0.2f) - 2.0f), ImColor(155, 155, 155, 78));//方框内部填充

//在方框内部绘制斜线网格线


   
   //方框里头像
       ImGui::GetForegroundDrawList()->AddImage(handId!= NULL ?  handId: 0, {(int)map_coord.X - (map_coord.H*0.2f), (int)map_coord.Y - (map_coord.H*0.2f)+ (-map_coord.H*1.0f)}, {(int)map_coord.X + (map_coord.H*0.2f), (int)map_coord.Y + (map_coord.H*0.2f)+ (-map_coord.H*1.0f)});
         
       
       //方框里血量
                    ImGui::GetForegroundDrawList()->AddCircleArc(ImVec2((int)map_coord.X,(int) map_coord.Y+ (-map_coord.H*1.0f)),(map_coord.H*0.22f)>0 ? (map_coord.H*0.22f) : 1, ImVec2(0, 360), Paint_white,  0, 5.5f);//白底背景
                    ImGui::GetForegroundDrawList()->AddCircleArc(ImVec2((int)map_coord.X, (int)map_coord.Y+ (-map_coord.H*1.0f)),(map_coord.H*0.22f)>0 ? (map_coord.H*0.22f) : 1, ImVec2(0, aa), 颜色配置.血量颜色,  0, 5.5f);//红色血圈
                    
                    }else{
                    
                    
                    ImGui::GetForegroundDrawList()->AddRect(ImVec2((int)map_coord.X - (map_coord.H*0.5f), (int)map_coord.Y - (map_coord.H*1.32f)), ImVec2((int)map_coord.X + (map_coord.H*0.5), (int)map_coord.Y + (map_coord.H*0.2f)), Paint_red, 0.0f, 0, 2.0f); //方框[ ]

// 绘制内部方框，覆盖外部方框
ImGui::GetForegroundDrawList()->AddRectFilled(ImVec2((int)map_coord.X - (map_coord.H*0.5f) + 2.0f, (int)map_coord.Y - (map_coord.H*1.32f) + 2.0f), ImVec2((int)map_coord.X + (map_coord.H*0.5f) - 2.0f, (int)map_coord.Y + (map_coord.H*0.2f) - 2.0f), ImColor(255, 0, 0, 78));//方框内部填充

//在方框内部绘制斜线网格线


   
   //方框里头像
       ImGui::GetForegroundDrawList()->AddImage(handId!= NULL ?  handId: 0, {(int)map_coord.X - (map_coord.H*0.2f), (int)map_coord.Y - (map_coord.H*0.2f)+ (-map_coord.H*1.0f)}, {(int)map_coord.X + (map_coord.H*0.2f), (int)map_coord.Y + (map_coord.H*0.2f)+ (-map_coord.H*1.0f)});
         
       
       //方框里血量
                    ImGui::GetForegroundDrawList()->AddCircleArc(ImVec2((int)map_coord.X,(int) map_coord.Y+ (-map_coord.H*1.0f)),(map_coord.H*0.22f)>0 ? (map_coord.H*0.22f) : 1, ImVec2(0, 360), Paint_white,  0, 5.5f);//白底背景
                    ImGui::GetForegroundDrawList()->AddCircleArc(ImVec2((int)map_coord.X, (int)map_coord.Y+ (-map_coord.H*1.0f)),(map_coord.H*0.22f)>0 ? (map_coord.H*0.22f) : 1, ImVec2(0, aa), 颜色配置.血量颜色,  0, 5.5f);//红色血圈
                    
                    }
                    
                    
                    
                    
                    
               /*     float max_hp_percentage = 1.0f;
								float current_hp_percentage = (float)dataTable.heroTemp[i].Hp / (float)dataTable.heroTemp[i].MaxHp;
								float bar_width = map_coord.H * 0.1f;  //血条宽度
								float bar_height = map_coord.H * 1.2f;  //血条长度
								float corner_radius = 5.0f;

								// 绘制最大血量条边框
								/*ImGui::GetForegroundDrawList()->AddRect(
									ImVec2((int)map_coord.X-8- bar_width / 2 - (-map_coord.H*0.65f), (int)map_coord.Y - (map_coord.H*1.35f)),
									ImVec2((int)map_coord.X-8 + bar_width / 2 - (-map_coord.H*0.65f), (int)map_coord.Y + bar_height - (map_coord.H*1.05f)),
									Paint_white,
									corner_radius
								);*/

								// 绘制最大血量条填充
							/*	ImGui::GetForegroundDrawList()->AddRectFilled(
									ImVec2((int)map_coord.X-8 - bar_width / 2 + corner_radius - (-map_coord.H*0.65f), (int)map_coord.Y + corner_radius - (map_coord.H*1.35f)),
									ImVec2((int)map_coord.X-8 + bar_width / 2 - corner_radius - (-map_coord.H*0.65f), (int)map_coord.Y + bar_height - corner_radius - (map_coord.H*1.05f)),
									Paint_white,
									corner_radius
								);

								// 计算当前血量条的填充高度和起始位置
								float current_hp_fill_height = bar_height * current_hp_percentage;
								float fill_correction_factor = 1.32f;  // 初始修正因子为1.35

								// 根据敌人剩余血量百分比动态调整修正因子的值
								if (current_hp_percentage <= 0.85f) {
									fill_correction_factor = 1.05f;
								}

								float current_hp_fill_start_y = (int)map_coord.Y + bar_height - current_hp_fill_height - (map_coord.H * fill_correction_factor);

								// 绘制当前血量条填充
								ImGui::GetForegroundDrawList()->AddRectFilled(
									ImVec2((int)map_coord.X-8 - bar_width / 2 + corner_radius - (-map_coord.H * 0.65000000f), current_hp_fill_start_y),
									ImVec2((int)map_coord.X -8+ bar_width / 2 - corner_radius - (-map_coord.H * 0.65f), (int)map_coord.Y + bar_height - (map_coord.H * 1.05f)),
									颜色配置.血量颜色,
									corner_radius
								);
                    */
                    
                    
                    
                    
                    
                    
    }
    }
    
                   
                                                       
 if(辅助方框){
 ImGui::GetForegroundDrawList()->AddRect(ImVec2(SmallMapX+80, SmallMapY-10), ImVec2(SmallMapX+2.73* rientation * Wwra , SmallMapY+2.13* rientation * Wwra ), 颜色配置.方框颜色, 5, 0);
 }                                                                         
                                                 
                                                                
                                                                                              
    if(射线){      
   if(视野==257){
      if(视野方框){
      ImGui::GetForegroundDrawList()->AddLine(ImVec2(yxpx/2, yxpy/2), ImVec2(map_coord.X, map_coord.Y + (-map_coord.H*1.0f)), 颜色配置.射线颜色, 1.5f);
      
      }
   }else{         
                    //射线
                     
                        ImGui::GetForegroundDrawList()->AddLine(ImVec2(yxpx/2, yxpy/2), ImVec2(map_coord.X, map_coord.Y + (-map_coord.H*1.0f)), 颜色配置.射线颜色, 1.5f);
    }               
                 }   
                    
                    
    
    dataTable.heroTemp[i].Space = driver->read<int>(driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(bingxiang6+0x148)+0x108)+0xa8)+0x3C)/8192000;
    
    
        dataTable.heroTemp[i].Skill = driver->read<int>(driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(bingxiang6+0x148)+0x150)+0xa8)+0x3c)/8192000;          
        
        
        
        
                    dataTable.heroTemp[i].TB = driver->read<int>(driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(bingxiang6+0x148) + 0x150) + 0x60) + 0x10);//召唤师图标
                                           
                                           
                                if (dataTable.heroTemp[i].TB != 80102 && dataTable.heroTemp[i].TB != 80103 &&
            dataTable.heroTemp[i].TB != 80104 && dataTable.heroTemp[i].TB != 80105 &&
            dataTable.heroTemp[i].TB != 80107 && dataTable.heroTemp[i].TB != 80108 &&
            dataTable.heroTemp[i].TB != 80109 && dataTable.heroTemp[i].TB != 80110 &&
            dataTable.heroTemp[i].TB != 80115 && dataTable.heroTemp[i].TB != 80121 &&
            dataTable.heroTemp[i].TB != 80116 && dataTable.heroTemp[i].TB != 801162 
            ) {
            dataTable.heroTemp[i].TB = 0;
        }                  
                                           
                                           
                                           
                //方框里技能
   if (方框技能) {
   
   if(视野==257){
   if(视野方框){
                       if (dataTable.heroTemp[i].Space > 0) {
                        int intvalue = dataTable.heroTemp[i].Space;
                        string test = std::to_string(intvalue);
                        ImGui::GetForegroundDrawList()->AddText(NULL, (float)((double)(0.266777647) * map_coord.H), ImVec2((float)map_coord.X + (map_coord.H*0.6)+ (-map_coord.H*1.06f), (float)map_coord.Y - (map_coord.H*0.07f)+ (map_coord.H*0.3f)-40), Paint_red,//方框大招字体
                                      test.c_str());
                    } else {
                        

ImGui::GetForegroundDrawList()->AddLine(ImVec2((float)map_coord.X + (map_coord.H*0.7f)+ (-map_coord.H*1.17f), (float)map_coord.Y + (map_coord.H*-0.14f)+ (map_coord.H*0.3f)),
ImVec2((float)map_coord.X + (map_coord.H*0.7f)+ (-map_coord.H*0.95f), (float)map_coord.Y + (map_coord.H*-0.14f)+ (map_coord.H*0.3f)), Paint_green, 5);

ImGui::GetForegroundDrawList()->AddLine(ImVec2((float)map_coord.X + (map_coord.H*0.7f)+ (-map_coord.H*1.17f), (float)map_coord.Y + (map_coord.H*-0.14f)+ (map_coord.H*0.3f)),
ImVec2((float)map_coord.X + (map_coord.H*0.7f)+ (-map_coord.H*1.17f), (float)map_coord.Y + (map_coord.H*-0.36f)+ (map_coord.H*0.3f)), Paint_green, 5);
//方框直角

                        
                        
                        
                        
                        
                        
                        
                        
                    }
                    if (dataTable.heroTemp[i].Skill > 0) {
                        int intvalue = dataTable.heroTemp[i].Skill;
                        string test = std::to_string(intvalue);
                        ImGui::GetForegroundDrawList()->AddText(NULL, (float)((double)(0.266777647) * map_coord.H), ImVec2((float)map_coord.X + (map_coord.H*0.6)+ (-map_coord.H*0.3f)-20, (float)map_coord.Y - (map_coord.H*0.07f)+ (map_coord.H*0.3f)-40), Paint_red,//方框召唤师字体
                                      test.c_str());
                    } else {
                       // ImGui::GetForegroundDrawList()->AddRectFilled(ImVec2((float)map_coord.X + (map_coord.H*0.6)+ (-map_coord.H*0.3f), (float)map_coord.Y - (map_coord.H*0.008f)+ (map_coord.H*0.3f)), ImVec2((float)map_coord.X + (map_coord.H*0.8)+ (-map_coord.H*0.3f), (float)map_coord.Y + (map_coord.H*0.2f)+ (map_coord.H*0.3f)), Paint_red, 0); //实体方点
                   
                        ImTextureID tubiaoid;
                    if(dataTable.heroTemp[i].TB!=0){
                    if(dataTable.heroTemp[i].TB==801162){
                        tubiaoid=reinterpret_cast<ImTextureID>(技能贴图.头像[dataTable.heroTemp[i].TB-800000].textureId);
    
                    }else{
                    tubiaoid=reinterpret_cast<ImTextureID>(技能贴图.头像[dataTable.heroTemp[i].TB-80000].textureId);
    }
    
    }else{tubiaoid =reinterpret_cast<ImTextureID>(技能贴图.头像[0].textureId);
    
                }
                    ImTextureID tubiaoid2 =reinterpret_cast<ImTextureID>(技能贴图.头像[0].textureId);
    
ImGui::GetForegroundDrawList()->AddImage(tubiaoid!= NULL ?  tubiaoid: tubiaoid2, ImVec2((float)map_coord.X +(map_coord.H*0.16)+(map_coord.H*0.3), (float)map_coord.Y -(map_coord.H*0.16)), ImVec2((float)map_coord.X -(map_coord.H*0.16)+(map_coord.H*0.3), (float)map_coord.Y +(map_coord.H*0.16)));//方框召唤师技能
   
   
   
   }
   }
   }else{
                    if (dataTable.heroTemp[i].Space > 0) {
                        int intvalue = dataTable.heroTemp[i].Space;
                        string test = std::to_string(intvalue);
                        ImGui::GetForegroundDrawList()->AddText(NULL, (float)((double)(0.266777647) * map_coord.H), ImVec2((float)map_coord.X + (map_coord.H*0.6)+ (-map_coord.H*1.06f), (float)map_coord.Y - (map_coord.H*0.07f)+ (map_coord.H*0.3f)-40), Paint_red,//方框大招字体
                                      test.c_str());
                    } else {
                        ImGui::GetForegroundDrawList()->AddLine(ImVec2((float)map_coord.X + (map_coord.H*0.7f)+ (-map_coord.H*1.17f), (float)map_coord.Y + (map_coord.H*-0.14f)+ (map_coord.H*0.3f)),
ImVec2((float)map_coord.X + (map_coord.H*0.7f)+ (-map_coord.H*0.95f), (float)map_coord.Y + (map_coord.H*-0.14f)+ (map_coord.H*0.3f)), Paint_green, 5);

ImGui::GetForegroundDrawList()->AddLine(ImVec2((float)map_coord.X + (map_coord.H*0.7f)+ (-map_coord.H*1.17f), (float)map_coord.Y + (map_coord.H*-0.14f)+ (map_coord.H*0.3f)),
ImVec2((float)map_coord.X + (map_coord.H*0.7f)+ (-map_coord.H*1.17f), (float)map_coord.Y + (map_coord.H*-0.36f)+ (map_coord.H*0.3f)), Paint_green, 5);
//方框直角


                    }
                    if (dataTable.heroTemp[i].Skill > 0) {
                        int intvalue = dataTable.heroTemp[i].Skill;
                        string test = std::to_string(intvalue);
                        ImGui::GetForegroundDrawList()->AddText(NULL, (float)((double)(0.266777647) * map_coord.H), ImVec2((float)map_coord.X + (map_coord.H*0.6)+ (-map_coord.H*0.3f)-20, (float)map_coord.Y - (map_coord.H*0.07f)+ (map_coord.H*0.3f)-40), Paint_red,//召唤师技能字体
                                      test.c_str());
                    } else {
                       // ImGui::GetForegroundDrawList()->AddRectFilled(ImVec2((float)map_coord.X + (map_coord.H*0.6)+ (-map_coord.H*0.3f), (float)map_coord.Y - (map_coord.H*0.008f)+ (map_coord.H*0.3f)), ImVec2((float)map_coord.X + (map_coord.H*0.8)+ (-map_coord.H*0.3f), (float)map_coord.Y + (map_coord.H*0.2f)+ (map_coord.H*0.3f)), Paint_red, 0); //实体方点
                   
                        ImTextureID tubiaoid;
                    if(dataTable.heroTemp[i].TB!=0){
                    if(dataTable.heroTemp[i].TB==801162){
                        tubiaoid=reinterpret_cast<ImTextureID>(技能贴图.头像[dataTable.heroTemp[i].TB-800000].textureId);
    
                    }else{
                    tubiaoid=reinterpret_cast<ImTextureID>(技能贴图.头像[dataTable.heroTemp[i].TB-80000].textureId);
    }
    
    }else{tubiaoid =reinterpret_cast<ImTextureID>(技能贴图.头像[0].textureId);
    
                }
                    ImTextureID tubiaoid2 =reinterpret_cast<ImTextureID>(技能贴图.头像[0].textureId);
    
ImGui::GetForegroundDrawList()->AddImage(tubiaoid!= NULL ?  tubiaoid: tubiaoid2, ImVec2((float)map_coord.X +(map_coord.H*0.16)+(map_coord.H*0.3), (float)map_coord.Y -(map_coord.H*0.16)), ImVec2((float)map_coord.X -(map_coord.H*0.16)+(map_coord.H*0.3), (float)map_coord.Y +(map_coord.H*0.16)));//方框召唤师技能
           
                        
                        }
                        }
                }
   
                
            
                
                
                    }//血量大于0
                    
                    
                    
                    
                    
                    
                    
                       //TODO：顶上技能
            if (顶上技能) {
                float Theoffset_X = CDjs_X + SmallMapX+jinenglanzX+113;
			    float Theoffset_Y = CDjs_Y + SmallMapY+jinenglanzY-4;
                float CDdrawXY[3][2] = {
								{(float)(Theoffset_X +  intervalcdX * opop), (float)(Theoffset_Y + intervalcdY * 0)},
								{(float)(Theoffset_X +  intervalcdX * opop), (float)(Theoffset_Y + (TXdx/2) + intervalcdY * 1)},
								{(float)(Theoffset_X +  intervalcdX * opop), (float)(Theoffset_Y + TXdx + intervalcdY * 2)}
								};
								
								
								
								
								
                const float _txt_X = Theoffset_X - (TXdx * 3.6f);
                if (opop == 0) {
                    ImGui::GetForegroundDrawList()->AddText(NULL, 28.0f, ImVec2((float)_txt_X-10.0f, (float)(CDdrawXY[0][1] + (TXdx/2))), Paint_red, "");//修改大招
                  //  draw->AddText(NULL, 28.0f, ImVec2((float)_txt_X, (float)(CDdrawXY[1][1] + (TXdx/2))), Paint_red, "头像:");
                    ImGui::GetForegroundDrawList()->AddText(NULL, 28.0f, ImVec2((float)_txt_X-10.0f, (float)(CDdrawXY[2][1] + (TXdx/2))), Paint_red, "");//修改召唤师

                }
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                CDdrawXY[1][0] = CDdrawXY[1][0] + (TXdx/14.0f); // x 二次改变偏移

                CDdrawXY[0][1] = CDdrawXY[0][1] + (TXdx) + (TXdx/5.0f);
                CDdrawXY[1][1] = CDdrawXY[1][1] + (TXdx) + (TXdx/5.0f);//绘制头像
                CDdrawXY[2][1] = CDdrawXY[2][1] + (TXdx) + (TXdx/5.0f);
                /*if (0==1) //显示回城
                    local_DrawHome(draw, CDdrawXY[1][0], CDdrawXY[1][1], renderScale, color);
float aa = hp*3.6;*/
                ImGui::GetForegroundDrawList()->AddImage(handId!= NULL ?  handId: 0, {CDdrawXY[1][0] - TXdx, CDdrawXY[1][1] - TXdx}, {CDdrawXY[1][0] + TXdx, CDdrawXY[1][1] + TXdx});//顶上头像
                

                ImU32 color = ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
ImGui::GetForegroundDrawList()->AddCircleArc(ImVec2(CDdrawXY[1][0], CDdrawXY[1][1]), 21, ImVec2(0, 360), color, 0, 5); // 顶上白色底圆边



                
                ImGui::GetForegroundDrawList()->AddCircleArc(ImVec2(CDdrawXY[1][0], CDdrawXY[1][1]),21, ImVec2(0, aa), 颜色配置.血量颜色,  0, 5);//顶上红色血圈边
                
                
                
                if (dataTable.heroTemp[i].Space > 0) { //绘制大招
                    int intvalue = dataTable.heroTemp[i].Space;
                    string test = std::to_string(intvalue);
                    ImGui::GetForegroundDrawList()->AddText(NULL, skills_txt_dx, ImVec2(CDdrawXY[0][0] - (TXdx/1.4), (CDdrawXY[0][1] - (TXdx/1.2))), Paint_white,test.c_str());
                } else {
                    ImGui::GetForegroundDrawList()->AddCircleFilled(ImVec2((float)CDdrawXY[0][0], (float)CDdrawXY[0][1]+23), skills_dx, Paint_green);//顶上技能颜色圆形
                 
                 
               // ImGui::GetForegroundDrawList()->AddTriangleFilled(ImVec2((float)CDdrawXY[0][0], (float)CDdrawXY[0][1]+23+1.1*skills_dx), ImVec2((float)CDdrawXY[0][0]-1.1*skills_dx, (float)CDdrawXY[0][1]+23-1.1*skills_dx), ImVec2((float)CDdrawXY[0][0]+1.1*skills_dx, (float)CDdrawXY[0][1]+23-1.1*skills_dx), Paint_green);//顶上技能颜色△三角形


                 
                 
                 
                }
                if (dataTable.heroTemp[i].Skill > 0) { //绘制召唤
                    int intvalue = dataTable.heroTemp[i].Skill;
                    string test = std::to_string(intvalue);
                    ImGui::GetForegroundDrawList()->AddText(NULL, skills_txt_dx, ImVec2(CDdrawXY[2][0] - (TXdx/1.4), (CDdrawXY[2][1] - (TXdx/1.2))), Paint_white,test.c_str());
                } else {
                   // ImGui::GetForegroundDrawList()->AddRect(ImVec2((float)CDdrawXY[2][0] - skills_dx, (float)CDdrawXY[2][1] - skills_dx), ImVec2((float)CDdrawXY[2][0] + skills_dx, (float)CDdrawXY[2][1] + skills_dx), Paint_red, skills_dx, 0, skills_dx*2);
                    
                    ImTextureID tubiaoid;
                    if(dataTable.heroTemp[i].TB!=0){
                    if(dataTable.heroTemp[i].TB==801162){
                        tubiaoid=reinterpret_cast<ImTextureID>(技能贴图.头像[dataTable.heroTemp[i].TB-800000].textureId);
    
                    }else{
                    tubiaoid=reinterpret_cast<ImTextureID>(技能贴图.头像[dataTable.heroTemp[i].TB-80000].textureId);
    }
    }else{tubiaoid =reinterpret_cast<ImTextureID>(技能贴图.头像[0].textureId);
    
                }
                    ImTextureID tubiaoid2 =reinterpret_cast<ImTextureID>(技能贴图.头像[0].textureId);
    
                
                    ImGui::GetForegroundDrawList()->AddImage(tubiaoid!= NULL ?  tubiaoid: tubiaoid2, {(float)CDdrawXY[2][0] - TXdx, CDdrawXY[2][1] - TXdx}, {(float)CDdrawXY[2][0] + TXdx, CDdrawXY[2][1] + TXdx});//顶上头像
                    
                    

ImGui::GetForegroundDrawList()->AddCircle({(float)CDdrawXY[2][0], CDdrawXY[2][1]}, TXdx, IM_COL32(128, 0, 128, 255), 0, 5.0f); // 绘制紫色圆圈
                    
                    
                    
                    
           
                    
                }
                if (hp1 <= 0)
                  //  draw->AddLine(ImVec2((CDdrawXY[1][0] - TXdx), (CDdrawXY[1][1] - TXdx)), ImVec2((CDdrawXY[1][0] + TXdx), (CDdrawXY[1][1] + TXdx)), Paint_red, 10.0f);
                    ImGui::GetForegroundDrawList()->AddText(NULL, 80, ImVec2(CDdrawXY[1][0] - (TXdx/1.2)-7, CDdrawXY[1][1] - (TXdx/0.45)), Paint_red,"x");//顶上xxxxx
            }
                
                    
                    opop++;
                    
                    
                    


}





        }
    
    
    
    }
    
    
        if (上帝) {
    //上帝so = driver->getModuleBase("libil2cpp.so");
		         long sdaddr = driver->read<uint64_t>(driver->read<uint64_t>(lil2cpp_base + 0x8be5220) + 0xA0) + 0x28;
driver->write<float>(sdaddr, shangdi);
                      
                      }       
    
    
    uint64_t BuffAddress;//buff数量地址
uint64_t BxAddress;//兵线数量地址
uint64_t bxAddress;//兵线属性首位置
uint64_t Buffsl;//buff坐标数量
    

if(野怪){
    
    //              ReadZZ(ReadZZ(ReadZZ(ReadZZ(ReadZZ(ReadZZ(libbuff) + 0xf0) + 0x108) + 0x138)+0x88)+0x120)+0x0;
       long temp2 = driver->read<uint64_t>(libGame_base + 0x3A3AF78);
        BuffAddress = driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(temp2 + 0x3b0)+ 0x88)+0x120)+0x0;
        for (int i = 0; i < 21; i++) {
            dataTable.pve[i].cd = driver->read<uint64_t>((u_long)(BuffAddress + i * 0x18)) + 0x238;
            dataTable.pve[i].maxcd = driver->read<uint64_t>((u_long)(BuffAddress + i * 0x18)) + 0x1e4;
            dataTable.pve[i].cc = driver->read<uint64_t>((u_long)(BuffAddress + i * 0x18));
            
            dataTable.pve[i].X = dataTable.pve[i].cc + 0x2b0;
            dataTable.pve[i].Y = dataTable.pve[i].cc + 0x2b8;
        }
        
        for (int i = 0; i < 21; i++) {
            dataTable.pveTemp[i].cd = driver->read<int>(dataTable.pve[i].cd) / 1000;
            dataTable.pveTemp[i].maxcd = driver->read<int>(dataTable.pve[i].maxcd) / 1000;
            dataTable.pveTemp[i].coord.X = (float) driver->read<int>(dataTable.pve[i].X);
            dataTable.pveTemp[i].coord.Y = (float) driver->read<int>(dataTable.pve[i].Y);
            dataTable.pveTemp[i].coord.X = (float)(dataTable.pveTemp[i].coord.X * rientation * Wwra / 50000.0f + Wwra);
            dataTable.pveTemp[i].coord.Y = (float)(dataTable.pveTemp[i].coord.Y * rientation * Wwra / 50000.0f  * -1 + Wwra);
        }
        if(1==1){
            for (int i = 0; i <21; i++) {
                
                if(dataTable.pveTemp[i].cd ==90||dataTable.pveTemp[i].cd == 70||dataTable.pveTemp[i].maxcd >90||dataTable.pveTemp[i].maxcd ==60){
                    continue;}
                if(dataTable.pveTemp[i].cd !=90||dataTable.pveTemp[i].cd !=70) {
                    
                    int intvalue = dataTable.pveTemp[i].cd;
                    string test = std::to_string(intvalue);
                    ImGui::GetForegroundDrawList()->AddText(NULL, 25.0f, ImVec2((float) (dataTable.pveTemp[i].coord.X +SmallMapX - 6.0+94),(float) (dataTable.pveTemp[i].coord.Y +SmallMapY - 7.9+7)),ImColor(255, 255, 255),test.c_str());
                }
            }
            
        }
	}
	
if(兵线){
    
    int number;//兵线数量
    
    long temp5 = driver->read<uint64_t>(libGame_base + 0x3B8F5D0);
    BxAddress = driver->read<uint64_t>(driver->read<uint64_t>(temp5 + 0x138) + 0x108);
    number = 50;
    
    
    long cont = 0;
    for (int l = 0; l < number; l++){
        bxAddress = driver->read<uint64_t>(BxAddress +( l * 0x18));
        int temp = driver->read<int>(bxAddress + 0x3c);
        if (temp == foeComp) {
        int bxxl = driver->read<int>(driver->read<uint64_t>(bxAddress + 0x160)+0xA0);

                dataTable.CeTemp[cont].coord.X = (float) driver->read<int>(driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(bxAddress +0x2b8 )+ 0x18) + 0x10) + 0x0);
                dataTable.CeTemp[cont].coord.Y = (float) driver->read<int>(driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(bxAddress +0x2b8 )+ 0x18) + 0x10) + 0x8);
                if (dataTable.CeTemp[cont].coord.X == 0 || dataTable.CeTemp[cont].coord.Y == 0) {continue;}
                 if (bxxl<=0) {continue;}
                dataTable.CeTemp[cont].coord.X = dataTable.CeTemp[cont].coord.X * rientation * Wwra / 50000.0f + Wwra;
                dataTable.CeTemp[cont].coord.Y = dataTable.CeTemp[cont].coord.Y * rientation * Wwra / 50000.0f * -1 + Wwra;
                cont++;
            
        }
    }
    dataTable.xbsl = cont;
    
    
    
    
            for(int i = 0; i < dataTable.xbsl;i++){
                float x = dataTable.CeTemp[i].coord.X + SmallMapX+94;
                float y = dataTable.CeTemp[i].coord.Y + SmallMapY+7;
                ImGui::GetForegroundDrawList()->AddRect(ImVec2((float)x - soldiers_dx, (float)y - soldiers_dx), ImVec2((float)x + soldiers_dx, (float)y + soldiers_dx), Paint_red, soldiers_dx, 0, soldiers_dx*2);
            }
        }
    
    
    
}

