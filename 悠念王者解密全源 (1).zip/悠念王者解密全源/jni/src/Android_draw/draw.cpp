#include <pthread.h>         // for thread(多线程)
#include "draw.h"
#include "Font.h"
#include "DrawPlayer.hpp"
#include "Layout.hpp"
#include "读取.h"
#include "2400.h"
bool permeate_record = false;
bool g_Initialized = false;
EGLDisplay display = EGL_NO_DISPLAY;
EGLConfig config;
EGLSurface surface = EGL_NO_SURFACE;
EGLContext context = EGL_NO_CONTEXT;
ANativeWindow *native_window;
android::ANativeWindowCreator::DisplayInfo displayInfo{0};

int screen_x = 0, screen_y = 0;
int abs_ScreenX = 0, abs_ScreenY = 0;
int native_window_screen_x = 0, native_window_screen_y = 0;



int init_egl(int _screen_x, int _screen_y, bool log) {
    /* static bool 防录屏开关 = false;
     native_window = android::ANativeWindowCreator::Create("Ssage7k7k", _screen_x, _screen_y, 防录屏开关);*/
bool status = false;  
char YN[32] = {0};
    printf("\n开启防录屏模式 [1]是 [2]否: ");
    scanf("%s", YN);  // 从标准输入流中读取字符串    

    if (strstr(YN, "1") != NULL) {
   // printf("\n防录屏已开启");
            status = true;
    } else {
    //    printf("\n防录屏已关启");
            status = false;        
    }

native_window = android::ANativeWindowCreator::Create("Ssage7k7k", _screen_x, _screen_y, status);
     

    ANativeWindow_acquire(native_window);

    ANativeWindow_acquire(native_window);
    display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display == EGL_NO_DISPLAY) {
        printf("eglGetDisplay error=%u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglGetDisplay ok\n");
    }
    if (eglInitialize(display, 0, 0) != EGL_TRUE) {
        printf("eglInitialize error=%u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglInitialize ok\n");
    }
    EGLint num_config = 0;
    const EGLint attribList[] = {
            EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
            EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
            EGL_BLUE_SIZE, 5,   //-->delete
            EGL_GREEN_SIZE, 6,  //-->delete
            EGL_RED_SIZE, 5,    //-->delete
            EGL_BUFFER_SIZE, 32,  //-->new field
            EGL_DEPTH_SIZE, 16,
            EGL_STENCIL_SIZE, 8,
            EGL_NONE
    };
    if (eglChooseConfig(display, attribList, nullptr, 0, &num_config) != EGL_TRUE) {
        printf("eglChooseConfig  error=%u\n", glGetError());
        return -1;
    }
    if(log){
        printf("num_config=%d\n", num_config);
    }
    if (!eglChooseConfig(display, attribList, &config, 1, &num_config)) {
        printf("eglChooseConfig  error=%u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglChooseConfig ok\n");
    }
    EGLint egl_format;
    eglGetConfigAttrib(display, config, EGL_NATIVE_VISUAL_ID, &egl_format);
    ANativeWindow_setBuffersGeometry(native_window, 0, 0, egl_format);
    const EGLint attrib_list[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    context = eglCreateContext(display, config, EGL_NO_CONTEXT, attrib_list);
    if (context == EGL_NO_CONTEXT) {
        printf("eglCreateContext  error = %u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglCreateContext ok\n");
    }
    surface = eglCreateWindowSurface(display, config, native_window, nullptr);
    if (surface == EGL_NO_SURFACE) {
        printf("eglCreateWindowSurface  error = %u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglCreateWindowSurface ok\n");
    }
    if (!eglMakeCurrent(display, surface, surface, context)) {
        printf("eglMakeCurrent  error = %u\n", glGetError());
        return -1;
    }
    if(log){
        printf("eglMakeCurrent ok\n");
    }
    
    
    
    return 1;
}




char *读取文件(char *path)
{
	FILE *fp;
	if ((fp = fopen(path, "r")) == NULL)
	{
		return NULL;
	}
	fseek(fp, 0, SEEK_END);
	int filesize = ftell(fp);
	char *str;
	str = (char *)malloc(filesize);
	rewind(fp);
	fread(str, 1, filesize, fp);
	str[filesize] = '\0';
	fclose(fp);
	return str;
}
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdbool.h>

#include<fstream>
#include<iostream>
#include <iostream>
#include<thread>
using namespace std;
#include <stdio.h>
#include <stdlib.h>
void 写出文件(char *aaa,char *bbb){
	
	system("mkdir -p  /storage/emulated/0/颜色");
	std::ofstream ofs;
	
	
	ofs.open(aaa, std::ios::out);

	ofs << bbb 
		;

	ofs.close();
}







void ImGui_init(){
    if (g_Initialized){
        return;
    }
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = NULL;
    switch (Color[0])
    {
        case 0:
           // ImGui::StyleColorsRed();
		   ImGui::StyleColorsDark;
        break;
        case 1:
            ImGui::StyleColorsBlue();
        break;
        case 2:
            ImGui::StyleColorsOrange();
        break;
	}
    
    //testtexure =  createTexture("/data/data/com.OpenRoot.Canvas/test.png");
    //这边自己填图片路径
   // 获取头像();
   FloatBall = ImAgeHeadFile1(悬浮球, sizeof(悬浮球));
	获取头像2();
	获取图标();
	
	
	char *ndhdh=读取文件("/storage/emulated/0/颜色/小x");
			if(ndhdh){SmallMapX= atof(ndhdh);}
			char *ndhdh2=读取文件("/storage/emulated/0/颜色/小y");
			if(ndhdh2){SmallMapY= atof(ndhdh2);}
	char *ndhdh3=读取文件("/storage/emulated/0/颜色/大x");
			if(ndhdh3){SmallHPX= atof(ndhdh3);}
			char *ndhdh5=读取文件("/storage/emulated/0/颜色/大y");
			if(ndhdh5){SmallHPY= atof(ndhdh5);}
	
			char *ndhdh6=读取文件("/storage/emulated/0/颜色/头像大小");
			if(ndhdh6){touxiangdaxiao= atof(ndhdh6);}
			
			
			char *ndhdh7=读取文件("/storage/emulated/0/颜色/小地图血量大小");
			if(ndhdh7){xiaodituxue= atof(ndhdh7);}
			
			char *ndhdh8=读取文件("/storage/emulated/0/颜色/小地图头像间隔");
			if(ndhdh8){jiange= atof(ndhdh8);}
	
			string LoadFile = "/sdcard/颜色/颜色配置";
	
	ReadDrawSet((总颜色 *)&颜色配置, LoadFile.c_str());
	
			
			
			char *ndhdh9=读取文件("/storage/emulated/0/颜色/分辨率使用");
			if(ndhdh9){fenblxx= 1;}else{fenblxx=0;}
			
			char *ndhdh10=读取文件("/storage/emulated/0/颜色/技能栏左右1");
			if(ndhdh10){jinenglanzX= atof(ndhdh10);}
			
			char *ndhdh12=读取文件("/storage/emulated/0/颜色/技能栏上下1");
			if(ndhdh12){jinenglanzY= atof(ndhdh12);}
			
				char *ndhdh11=读取文件("/storage/emulated/0/颜色/上帝高度");
			if(ndhdh11){shangdi= atof(ndhdh11);}
			
				char *ndhdh13=读取文件("/storage/emulated/0/颜色/屏幕x");
			if(ndhdh13){屏幕x= atof(ndhdh13);}
			
				char *ndhdh14=读取文件("/storage/emulated/0/颜色/屏幕y");
			if(ndhdh14){屏幕y= atof(ndhdh14);}
			
    ImGui_ImplAndroid_Init(native_window);
    ImGui_ImplOpenGL3_Init("#version 300 es");
    ImFontConfig font_cfg;
    font_cfg.SizePixels = 22.0f;
    io.Fonts->AddFontFromMemoryTTF((void *) font_v, font_v_size, 28.0f, NULL, io.Fonts->GetGlyphRangesChineseFull());
    io.Fonts->AddFontDefault(&font_cfg);
    ImGui::GetStyle().ScaleAllSizes(3.0f);
    g_Initialized = true;
}



void 透视(){
    char mname[] = "libil2cpp.so"; // 基址入口模块
        long int fool = get_module_base(pid, mname);
        long int a1 = getPtr64(getPtr64(fool + 0x9B4A8A8) + 0xa0)+0x24;
        WriteAddress_DWORD(a1, 1071225242);
    
}
    

///////////
int huitu=0;
void tick() {
      ImGuiIO& io = ImGui::GetIO();
      static ImVec4 clear_color = ImVec4(0, 0, 0, 0);
      ImGuiStyle& style = ImGui::GetStyle();
		
style.Colors[ImGuiCol_Text] = ImColor(0.00f, 0.00f, 0.00f, 0.75f);//字体颜色
style.Colors[ImGuiCol_WindowBg] = ImColor(0.92f, 0.92f, 0.92f, 0.78f);//背景色
style.Colors[ImGuiCol_Border] = ImColor(1.00f, 1.00f, 1.00f, 0.50f);	

style.Colors[ImGuiCol_Button] = ImColor(1.0f, 1.0f, 0.35f, 1.00f);//按钮颜色
style.Colors[ImGuiCol_ButtonHovered] = ImColor(1.0f, 1.0f, 0.6f, 1.00f);//按钮点击后悬停颜色
style.Colors[ImGuiCol_ButtonActive] = ImColor(1.00f, 1.00f, 1.00f, 0.67f);//按钮点击颜色

style.Colors[ImGuiCol_Tab] = ImColor(235,194,194,255);//按钮颜色
style.Colors[ImGuiCol_TabHovered] = ImColor(235,194,194,225);//按钮点击后悬停颜色
style.Colors[ImGuiCol_TabActive] = ImColor(235,194,194,225);//按钮点击颜色
	
style.Colors[ImGuiCol_FrameBg] = ImColor(1.00f, 1.00f, 1.00f, 0.54f);//滑块，选框内背景色
style.Colors[ImGuiCol_FrameBgActive] = ImColor(1.00f, 1.00f, 1.00f, 0.40f);//控件内点击背景色
style.Colors[ImGuiCol_FrameBgHovered] = ImColor(1.00f, 1.00f, 1.00f, 0.67f);//控件内点击后悬停背景色
	
style.Colors[ImGuiCol_CheckMark] = ImColor(1.0f, 1.0f, 0.3f, 1.00f);//√的颜色
	
style.Colors[ImGuiCol_SliderGrab] = ImColor(1.00f, 1.00f, 0.30f, 1.0f);//滑块颜色
style.Colors[ImGuiCol_SliderGrabActive] = ImColor(1.00f, 1.00f, 0.00f, 1.0f);//滑块被拖动的颜色
	
style.Colors[ImGuiCol_Header] = ImColor(232,164,164,255);
style.Colors[ImGuiCol_HeaderHovered] = ImColor(232,164,164,255);
style.Colors[ImGuiCol_HeaderActive] = ImColor(232,164,164,255);//滑块按钮

style.Colors[ImGuiCol_ScrollbarBg] = ImColor(1.00f, 1.00f, 1.00f, 0.10f);//滑动条背景颜色
style.Colors[ImGuiCol_ScrollbarGrab] = ImColor(1.00f, 1.00f, 1.00f, 1.00f);//滑动条颜色
style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImColor(1.00f, 1.00f, 1.00f, 1.00f);//滚动条点击后悬停
style.Colors[ImGuiCol_ScrollbarGrabActive] = ImColor(1.00f, 1.00f, 1.00f, 1.00f);//滑动条点击
style.Colors[ImGuiCol_Separator] = ImColor(80,80,80,255);

style.GrabRounding = 25.0f;
style.GrabMinSize = 35.0f;

style.FrameRounding = 40.0f;
style.FrameBorderSize = 0.5f;
style.FramePadding = ImVec2(5, 5);

style.ScrollbarSize = 35.0f;
style.ScrollbarRounding = 13.0f;

style.WindowBorderSize = 8.0f;
style.WindowTitleAlign = ImVec2(0.5, 0.5);


///////////

		static bool IsBall = true;
        static float ANIM_SPEED = 0.25f;
    	static float Velua = IsBall ? 0.0f : 1.0f;
        Velua = ImClamp(Velua + (io.DeltaTime / ANIM_SPEED) * (IsBall ? 1.0f : -1.0f), 0.0f, 1.0f);
        if ((1150 * Velua) <= 1150 && (850 * Velua) <= 850) {
            ImGui::SetWindowSize("内部解密", {1190 * Velua, 860 * Velua});
        } else if ((850 * Velua) >= 100 && (850 * Velua) >= 100) {
            ImGui::SetWindowSize("内部解密", {1150 * Velua, 850 * Velua});
        } if ((1150 * Velua) <= 100 && !IsBall) {BallSwitch = true;MemuSwitch = false;}
        
if (BallSwitch)//悬浮球调整
{
    style.WindowRounding = 80.0f;
    if (ImGui::Begin("Ball", &BallSwitch,  ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar))
    {
        auto Pos = ImGui::GetWindowPos();
        Window = ImGui::GetCurrentWindow();
        DrawLogo({Pos.x + 50, Pos.y + 50}, 70);
        
        ImDrawList* draw_list = ImGui::GetWindowDrawList();
        ImVec2 size = ImGui::GetWindowSize();
        ImVec2 center = ImVec2(Pos.x + size.x / 2+2, Pos.y - 50 + size.y / 2-2);
        draw_list->AddCircle(center, size.x / 3, IM_COL32(148, 148, 148, 255), 40, 6.1f); // Add a thicker purple circle surrounding the ball
        
        if (ImGui::IsItemActive()) {
            if (!IsDown) {
                IsDown = true;
                ImagePos = ImGui::GetWindowPos();
            }
        } else if (IsDown) {
            IsDown = false;
            if(ImagePos.x == ImGui::GetWindowPos().x && ImagePos.y == ImGui::GetWindowPos().y) {
                IsBall = true;
                MemuSwitch = true;
                BallSwitch = false;
                ImGui::SetWindowPos("内部解密", Pos, ImGuiCond_Always);
            }
        }
    }
    ImGui::End();
}
        
        if(MemuSwitch)
        {
            style.WindowRounding = 10.0f;
        if (ImGui::Begin("内部解密", &MemuSwitch, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar))
        {
				auto Pos = ImGui::GetWindowPos();
        		Window = ImGui::GetCurrentWindow();
    			//ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {25 , 25});
    			
    			
        if (ImGui::BeginChild("##主菜单", ImVec2(502, -1), false, ImGuiWindowFlags_NoScrollbar))
        {
			    ImFont* customFont = io.Fonts->AddFontFromFileTTF("path/to/your/font.ttf", 50); // 这里的 40 是字体大小，可以根据需要调整
                ImGui::TextColored(ImColor(0.0f,0.0f,0.0f,0.75f), "内部工作室解密内核");			
                

//@@@@@@@@			
       /*       ImGui::SameLine();
    			ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {25 , 25});
    			ImGui::SameLine();
                if (ImGui::BeginChild("##缩小菜单", ImVec2(-1, -1), false, ImGuiWindowFlags_NoScrollbar))
                {
                    ImGui::ItemSize(ImVec2(0, 4));                  
                    ImGui::SameLine();
                    if (ImGui::GetWindowWidth() - (100 + 50 + 30) > 0) {
                        ImGui::InvisibleButton(" X ", {ImGui::GetWindowWidth() - (100 + 50 + 30), 0});
                    }
                    ImGui::SameLine();
                    if (ButtonTextColored(style.Colors[ImGuiCol_Button]," X "))
                    {
                        IsBall = false;
    					ImGui::SetWindowPos("Ball", Pos, ImGuiCond_Always);
    				}
    
                   ImGui::ItemSize(ImVec2(0, 4));
                   // ImGui::Separator();
                   ImGui::ItemSize(ImVec2(0, 10));
				   }
*/
//@@@@@@@@@

    //ImGui::SameLine();
    //if (ImGui::Button("主页", ImVec2(120, 50)))
    {
        MenuTab = 1;
    }
        


//第一页
//ImGui::Separator();//横线分割
ImGui::SetCursorPosY(55);//选项菜单窗口上下控制
switch (MenuTab)
{
case 1:
{							

ImGui::SetCursorPosY(ImGui::GetCursorPosY() + -10); // 将光标位置向上移动300个像素
if(huitu==0){
if(ImGui::Button("开启辅助", ImVec2(475, 75))){DrawInit();
huitu=1;血量=1;地图=1;射线=1;视野方框=1;方框=1;野怪=1;兵线=1;方框技能=1;顶上技能=1;上帝=0;自身判断=1;坐标解密1=1;}
}else{
if(ImGui::Button("关闭绘制", ImVec2(475, 75))){
huitu=0;血量=0;地图=0;射线=0;方框=0;野怪=0;兵线=0;方框技能=0;顶上技能=0;视野方框=0;上帝=0;自身判断=0;坐标解密1=0;坐标解密2=0;}						  
}


					/*  ImGui::Checkbox("解密坐标①", &最新);
					  ImGui::SameLine();
					  ImGui::Checkbox("解密坐标②", &旧版);*/
					 // ImGui::Text("");
					 ImGui::Text("\n");
					  ImGui::Checkbox("地图头像", &地图);
					  ImGui::SameLine();
					  ImGui::Checkbox("人物方框", &方框);
					  ImGui::SameLine();
					  ImGui::Checkbox("方框技能", &方框技能);
					  
					  ImGui::Checkbox("顶上技能", &顶上技能);
					  ImGui::SameLine();
					  ImGui::Checkbox("显示兵线", &兵线);
		              ImGui::SameLine();
					  ImGui::Checkbox("显示野怪", &野怪);
					  
					  ImGui::Checkbox("显示射线", &射线);
		              ImGui::SameLine();
					  ImGui::Checkbox("漏人不绘", &视野方框);
			     	  ImGui::SameLine();
					  ImGui::Checkbox("自身视野", &自身判断);
				   	  ImGui::Text("\n");
					  ImGui::Checkbox("上帝视角", &上帝);	ImGui::SameLine();
					  ImGui::PushItemWidth(460); // 设置滑块宽度为200
					  ImGui::Text("(内存功能慎重使用)");
		              if(ImGui::SliderFloat("", &shangdi, 1.2f, 2.2f, "%.2f", 1.0f))
                      {char urlls[2560];
	                  sprintf(urlls, "%.2f", shangdi);	
	                  写出文件("/storage/emulated/0/颜色/上帝高度",urlls);}
	
		
//第二页		
//ImGui::Separator();//横线分割
ImGui::Text("\n");
ImGui::TextColored(ImColor(0.0f,0.0f,0.0f,0.75f), 
"坐标解密(选择其一即可)");
ImGui::Checkbox("坐标解密方案一", &坐标解密1);

if (坐标解密1) {
    坐标解密2 = false;
	坐标解密3 = false;
	坐标解密4 = false;
	
} 

ImGui::SameLine();
ImGui::Checkbox("坐标解密方案二", &坐标解密2);

if (坐标解密2) {
    坐标解密1 = false;
	坐标解密3 = false;
	坐标解密4 = false;
	
}

ImGui::Checkbox("坐标解密方案三", &坐标解密3);

if (坐标解密3) {
	坐标解密1 = false;
    坐标解密2 = false;
	坐标解密4 = false;
	
} 

ImGui::SameLine();
ImGui::Checkbox("坐标解密方案四", &坐标解密4);

if (坐标解密4) {
    坐标解密1 = false;
	坐标解密2 = false;
	坐标解密3 = false;
	
}

ImGui::Checkbox("坐标解密方案五", &坐标解密4);

if (坐标解密4) {
    坐标解密1 = false;
	坐标解密2 = false;
	坐标解密3 = false;
	
}

//第三页		
//ImGui::Separator();//横线分割

}
//ImGui::SameLine( 0, 90 );
// ImGui::Text("     ");
//ImGui::SameLine();
ImGui::SetCursorPosY(719);//选项菜单窗口上下控制
if(ImGui::Button("退出", ImVec2(239, 90))){exit(1);
}
  ImGui::SameLine();
  if (ImGui::Button("缩小", ImVec2(239, 90))){
  IsBall = false;
}
    }
ImGui::EndChild();  				  
                   


//第四页
        
	    //ImGui::SameLine();
        ImGui::SeparatorEx(ImGuiSeparatorFlags_Vertical);	
    	ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {25 , 70});    
		ImGui::PushItemWidth(430); // 设置滑块宽度为200
		ImGui::SetCursorPosY(ImGui::GetCursorPosY() + -820); // 将光标位置向上移动300个像素
        
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素
		if(ImGui::SliderInt("自身视野X", &屏幕x,-2000,3500,"%.0f",2)){char urlls[2560];
		sprintf(urlls, "%d", 屏幕x);		
		写出文件("/storage/emulated/0/颜色/屏幕x",urlls);}
		
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素
		if(ImGui::SliderInt("自身视野Y", &屏幕y,-1000,1000,"%.0f",2)){char urlls[2560];
		sprintf(urlls, "%d", 屏幕y);		
		写出文件("/storage/emulated/0/颜色/屏幕y",urlls);}               
		
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素
		if(ImGui::SliderInt("小地图头像大小", &touxiangdaxiao,-300,300,"%.0f",2)){char urlls[2560];
		sprintf(urlls, "%d", touxiangdaxiao);		
		写出文件("/storage/emulated/0/颜色/头像大小",urlls);}
			
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素		
		if(ImGui::SliderInt("小地图血量大小", &xiaodituxue,-80,80,"%.0f",2)){char urlls[2560];
		sprintf(urlls, "%d", xiaodituxue);
		写出文件("/storage/emulated/0/颜色/小地图血量大小",urlls);}
			
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素		
		if(ImGui::SliderInt("小地图头像间隔", &jiange,-100,100,"%.0f",2)){char urlls[2560];
		sprintf(urlls, "%d", jiange);
		写出文件("/storage/emulated/0/颜色/小地图头像间隔",urlls);}
		
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素
	 if(ImGui::SliderInt("头像X", &SmallMapX,-300,300,"%.0f",2)){char urlls[2560];
		sprintf(urlls, "%d", SmallMapX);
		写出文件("/storage/emulated/0/颜色/小x",urlls);}
		
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素
     if(ImGui::SliderInt("头像Y", &SmallMapY,-300,300,"%.0f",2)){char urlls[2560];
		sprintf(urlls, "%d", SmallMapY);
		写出文件("/storage/emulated/0/颜色/小y",urlls);}
	
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素
     if(ImGui::SliderInt("大地图X", &SmallHPX,-300,300,"%.0f",2)){char urlls[2560];
		sprintf(urlls, "%d", SmallHPX);
		写出文件("/storage/emulated/0/颜色/大x",urlls);}
		
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素
     if(ImGui::SliderInt("大地图Y", &SmallHPY,-300,300,"%.0f",2)){char urlls[2560];
		sprintf(urlls, "%d", SmallHPY);
		写出文件("/storage/emulated/0/颜色/大y",urlls);}
					  
	    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素		  
	 if(ImGui::SliderInt("技能左右", &jinenglanzX,-2000,2000,"%.0f",2)){char urlls[2560];
		sprintf(urlls, "%d", jinenglanzX);
		写出文件("/storage/emulated/0/颜色/技能栏左右1",urlls);}
		
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素
	 if(ImGui::SliderInt("技能上下", &jinenglanzY,-500,500,"%.0f",2)){char urlls[2560];
		sprintf(urlls, "%d", jinenglanzY);
		写出文件("/storage/emulated/0/颜色/技能栏上下1",urlls);}
		
		ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 9); // 将光标位置向上移动300个像素
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素
        ImGui::ColorEdit3("血量颜色",(float*)&颜色配置.血量颜色);
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素
        ImGui::ColorEdit3("射线颜色",(float*)&颜色配置.射线颜色);
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素
	    ImGui::ColorEdit3("方框颜色",(float*)&颜色配置.方框颜色);
		
		
	    	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 6); // 将光标位置向上移动300个像素
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 544); // 将光标位置向右移动300个像素
    if (ImGui::Button("保存配置",{270, 90})) {
        string SaveFile ;                 
        SaveFile = "/sdcard/颜色/颜色配置";
		SaveDrawSet((总颜色 *)&颜色配置, SaveFile.c_str());
        }
		
		 ImGui::SameLine();
    if (ImGui::Button("删除颜色配置",{270, 90})) {
        system("rm /sdcard/颜色/颜色配置");
                    }
                    
                }
           
                ImGui::EndChild();
                ImGui::PopStyleVar(1);
            }
            ImGui::End();
        }
    
		if (IsWin)
		{
			IsWin = false;
            IsLoGin = false;
            BallSwitch = false;
            ImGui::SetWindowSize("Ball", {100.0f, 100.0f});
        } 
		

	/*****绘制帧率*****/
	char fkhs[1000];
    //sprintf(fkhs,"%.1f FPS",ImGui::GetIO().Framerate);
  //  ImGui::GetForegroundDrawList()->AddText(ImVec2(300, 1000),ImColor(225,255,255),fkhs);
   // ImGui::GetForegroundDrawList()->AddText(ImVec2(90, 1000),ImColor(225,255,255),"TS内部解密 状态稳定");
    /*****结束*****/
	if(huitu==1){
	DrawPlayer(); //调用绘图  直接写在这边的话有点影响观看了
	}
}




void screen_config() {
    ::displayInfo = android::ANativeWindowCreator::GetDisplayInfo();
    ::screen_x = displayInfo.width;
    ::screen_y = displayInfo.height;
}



void drawBegin() {
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(native_window_screen_x, native_window_screen_y);
    ImGui::NewFrame();
    
    screen_config();
    
    static uint32_t orientation = -1;
    if (orientation != displayInfo.orientation) {
        orientation = displayInfo.orientation;
        Touch::setOrientation(displayInfo.orientation);
        //cout << " width:" << displayInfo.width << " height:" << displayInfo.height << " orientation:" << displayInfo.orientation << endl;
    }    
}

void drawEnd() {
    ImGuiIO &io = ImGui::GetIO();
    glViewport(0.0f, 0.0f, (int) io.DisplaySize.x, (int) io.DisplaySize.y);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT); // GL_DEPTH_BUFFER_BIT
    glFlush();
    if (display == EGL_NO_DISPLAY) {
        return;
    }
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(display, surface);
}

void shutdown() {
    if (!g_Initialized) {
        return;
    }
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();
    if (display != EGL_NO_DISPLAY){
        eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (context != EGL_NO_CONTEXT){
            eglDestroyContext(display, context);
        }
        if (surface != EGL_NO_SURFACE){
            eglDestroySurface(display, surface);
        }
        eglTerminate(display);
    }
    display = EGL_NO_DISPLAY;
    context = EGL_NO_CONTEXT;
    surface = EGL_NO_SURFACE;
    ANativeWindow_release(native_window);
}
